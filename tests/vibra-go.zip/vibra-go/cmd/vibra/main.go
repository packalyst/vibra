package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/spf13/cobra"

	"github.com/packalyst/vibra-go/internal/api"
	"github.com/packalyst/vibra-go/internal/database"
	"github.com/packalyst/vibra-go/internal/proxy"
	"github.com/packalyst/vibra-go/internal/recognition"
)

var (
	version   = "0.1.0"
	dataDir   = "./data"
	staticDir = ""
	port      = 8080
)

func main() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

var rootCmd = &cobra.Command{
	Use:   "vibra",
	Short: "Vibra - Music Organizer",
	Long: `Vibra is a music recognition and organization tool.
It identifies songs using Shazam, AcoustID, and MusicBrainz,
then organizes your music library with proper tags and folder structure.`,
	Version: version,
}

var serveCmd = &cobra.Command{
	Use:   "serve",
	Short: "Start the web server",
	Long:  "Start the HTTP server with the web UI for managing your music library.",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Printf("Starting Vibra server on port %d...\n", port)
		fmt.Printf("Data directory: %s\n", dataDir)
		fmt.Printf("Open http://localhost:%d in your browser\n", port)

		// Initialize database
		if err := database.Init(dataDir); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize database: %v\n", err)
			os.Exit(1)
		}
		defer database.Close()

		// Create repositories
		fileRepo := database.NewFileRepository()
		settingsRepo := database.NewSettingsRepository()

		// Create proxy manager
		proxyMgr := proxy.NewManager(proxy.Config{})

		// Create recognition orchestrator with default config
		orchestrator := recognition.NewOrchestrator(recognition.DefaultConfig(), proxyMgr)

		// Create and start server
		server := api.NewServer(port, staticDir, fileRepo, settingsRepo, proxyMgr, orchestrator)

		// Handle graceful shutdown
		go func() {
			sigChan := make(chan os.Signal, 1)
			signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
			<-sigChan
			fmt.Println("\nShutting down...")
			os.Exit(0)
		}()

		if err := server.Start(); err != nil {
			fmt.Fprintf(os.Stderr, "Server error: %v\n", err)
			os.Exit(1)
		}
	},
}

var scanCmd = &cobra.Command{
	Use:   "scan [directory]",
	Short: "Scan a directory for music files",
	Long:  "Recursively scan a directory for supported audio files and import them into the database.",
	Args:  cobra.ExactArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		dir := args[0]
		fmt.Printf("Scanning directory: %s\n", dir)
		// TODO: Implement scanner
	},
}

var analyzeCmd = &cobra.Command{
	Use:   "analyze",
	Short: "Analyze pending files",
	Long:  "Recognize pending music files using configured services (Shazam, AcoustID, etc.)",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Analyzing pending files...")
		// TODO: Implement analyzer
	},
}

var organizeCmd = &cobra.Command{
	Use:   "organize",
	Short: "Organize recognized files",
	Long:  "Move/copy recognized files to the output directory using the configured organization pattern.",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Organizing files...")
		// TODO: Implement organizer
	},
}

var statusCmd = &cobra.Command{
	Use:   "status",
	Short: "Show library status",
	Long:  "Display statistics about the music library (total files, recognized, pending, errors).",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Library Status:")
		fmt.Println("  Total files:    0")
		fmt.Println("  Recognized:     0")
		fmt.Println("  Pending:        0")
		fmt.Println("  Errors:         0")
		// TODO: Query database for stats
	},
}

func init() {
	// Global flags
	rootCmd.PersistentFlags().StringVar(&dataDir, "data-dir", "./data", "Data directory for database and cache")

	// Serve command flags
	serveCmd.Flags().IntVarP(&port, "port", "p", 8080, "HTTP server port")
	serveCmd.Flags().StringVar(&staticDir, "static-dir", "", "Static files directory for web UI")

	// Analyze command flags
	analyzeCmd.Flags().IntP("workers", "w", 4, "Number of parallel workers")
	analyzeCmd.Flags().IntP("batch-size", "b", 100, "Batch size for processing")

	// Add commands
	rootCmd.AddCommand(serveCmd)
	rootCmd.AddCommand(scanCmd)
	rootCmd.AddCommand(analyzeCmd)
	rootCmd.AddCommand(organizeCmd)
	rootCmd.AddCommand(statusCmd)
}
