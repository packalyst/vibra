package worker

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/packalyst/vibra-go/internal/database"
	"github.com/packalyst/vibra-go/internal/proxy"
	"github.com/packalyst/vibra-go/internal/recognition"
	"github.com/packalyst/vibra-go/pkg/metadata"
)

// Job represents a file to be processed
type Job struct {
	File *database.File
}

// Result represents the result of processing a file
type Result struct {
	File     *database.File
	Metadata *metadata.Unified
	Error    error
	Duration time.Duration
}

// Progress represents analysis progress
type Progress struct {
	Total     int64  `json:"total"`
	Completed int64  `json:"completed"`
	Succeeded int64  `json:"succeeded"`
	Failed    int64  `json:"failed"`
	Current   string `json:"current"`
	Service   string `json:"service"`
	Done      bool   `json:"done"`
}

// Pool manages a pool of workers for parallel processing
type Pool struct {
	numWorkers   int
	fileRepo     *database.FileRepository
	orchestrator *recognition.Orchestrator
	proxyMgr     *proxy.Manager

	// Channels
	jobs    chan Job
	results chan Result

	// State
	ctx    context.Context
	cancel context.CancelFunc
	wg     sync.WaitGroup

	// Progress
	progress Progress
	mu       sync.RWMutex

	// Event callbacks
	onProgress func(Progress)
	onResult   func(Result)
	onLog      func(level, message string)

	// Configuration
	delayBetweenJobs time.Duration
}

// NewPool creates a new worker pool
func NewPool(
	numWorkers int,
	fileRepo *database.FileRepository,
	orchestrator *recognition.Orchestrator,
	proxyMgr *proxy.Manager,
) *Pool {
	ctx, cancel := context.WithCancel(context.Background())

	return &Pool{
		numWorkers:   numWorkers,
		fileRepo:     fileRepo,
		orchestrator: orchestrator,
		proxyMgr:     proxyMgr,
		jobs:         make(chan Job, numWorkers*2),
		results:      make(chan Result, numWorkers*2),
		ctx:          ctx,
		cancel:       cancel,
	}
}

// SetProgressHandler sets the progress callback
func (p *Pool) SetProgressHandler(handler func(Progress)) {
	p.onProgress = handler
}

// SetResultHandler sets the result callback
func (p *Pool) SetResultHandler(handler func(Result)) {
	p.onResult = handler
}

// SetLogHandler sets the logging callback
func (p *Pool) SetLogHandler(handler func(level, message string)) {
	p.onLog = handler
}

// SetDelayBetweenJobs sets the delay between processing jobs
func (p *Pool) SetDelayBetweenJobs(d time.Duration) {
	p.delayBetweenJobs = d
}

func (p *Pool) log(level, message string) {
	if p.onLog != nil {
		p.onLog(level, message)
	}
}

func (p *Pool) reportProgress() {
	p.mu.RLock()
	prog := p.progress
	p.mu.RUnlock()

	if p.onProgress != nil {
		p.onProgress(prog)
	}
}

// Start starts the worker pool
func (p *Pool) Start() {
	p.log("info", fmt.Sprintf("Starting worker pool with %d workers", p.numWorkers))

	// Start workers
	for i := 0; i < p.numWorkers; i++ {
		p.wg.Add(1)
		go p.worker(i)
	}

	// Start result collector
	go p.collectResults()
}

// Stop stops the worker pool
func (p *Pool) Stop() {
	p.log("info", "Stopping worker pool...")
	p.cancel()
	close(p.jobs)
	p.wg.Wait()
	close(p.results)
	p.log("info", "Worker pool stopped")
}

// Submit submits a job to the pool
func (p *Pool) Submit(job Job) {
	select {
	case p.jobs <- job:
	case <-p.ctx.Done():
	}
}

// SubmitBatch submits a batch of jobs
func (p *Pool) SubmitBatch(files []*database.File) {
	p.mu.Lock()
	p.progress.Total = int64(len(files))
	p.progress.Completed = 0
	p.progress.Succeeded = 0
	p.progress.Failed = 0
	p.progress.Done = false
	p.mu.Unlock()

	p.reportProgress()

	for _, file := range files {
		p.Submit(Job{File: file})
	}
}

// Wait waits for all jobs to complete
func (p *Pool) Wait() {
	p.wg.Wait()
}

// GetProgress returns current progress
func (p *Pool) GetProgress() Progress {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.progress
}

func (p *Pool) worker(id int) {
	defer p.wg.Done()

	for {
		select {
		case <-p.ctx.Done():
			return
		case job, ok := <-p.jobs:
			if !ok {
				return
			}
			p.processJob(id, job)
		}
	}
}

func (p *Pool) processJob(workerID int, job Job) {
	startTime := time.Now()
	file := job.File

	p.log("info", fmt.Sprintf("Processing: %s", file.Path))

	// Update current file in progress
	p.mu.Lock()
	p.progress.Current = file.Path
	p.mu.Unlock()
	p.reportProgress()

	// Wait if rate limited
	if err := p.proxyMgr.WaitIfRateLimited(p.ctx); err != nil {
		p.results <- Result{
			File:  file,
			Error: err,
		}
		return
	}

	// Update file status to analyzing
	p.fileRepo.UpdateStatus(file.ID, database.StatusAnalyzing)

	// Run recognition
	meta, err := p.orchestrator.Recognize(p.ctx, file.Path)

	result := Result{
		File:     file,
		Metadata: meta,
		Error:    err,
		Duration: time.Since(startTime),
	}

	// Update file in database
	if err != nil {
		p.fileRepo.SetError(file.ID, err.Error())
		p.log("error", fmt.Sprintf("Worker %d: failed to recognize %s: %v", workerID, file.Path, err))
	} else if meta != nil {
		// Update file with metadata
		file.Status = database.StatusRecognized
		file.Title = meta.Title
		file.Artist = meta.Artist
		file.Album = meta.Album
		file.Year = meta.Year
		file.Genre = meta.GetPrimaryGenre()
		file.TrackNumber = meta.TrackNumber
		file.DiscNumber = meta.DiscNumber
		file.Duration = meta.Duration
		file.ISRC = meta.ISRC
		file.RecognitionService = meta.Service
		file.Confidence = meta.Confidence
		file.ShazamID = meta.ShazamID
		file.MusicBrainzID = meta.MusicBrainzID
		file.ITunesID = meta.ITunesID
		file.ArtworkURL = meta.GetBestArtworkURL()

		p.fileRepo.UpdateRecognition(file)
		p.log("info", fmt.Sprintf("Worker %d: recognized %s - %s (%.2fs)",
			workerID, meta.Artist, meta.Title, result.Duration.Seconds()))
	}

	p.results <- result

	// Apply delay between jobs if configured
	if p.delayBetweenJobs > 0 {
		select {
		case <-time.After(p.delayBetweenJobs):
		case <-p.ctx.Done():
		}
	}
}

func (p *Pool) collectResults() {
	for result := range p.results {
		p.mu.Lock()
		p.progress.Completed++
		if result.Error != nil {
			p.progress.Failed++
		} else {
			p.progress.Succeeded++
		}
		if result.Metadata != nil {
			p.progress.Service = result.Metadata.Service
		}

		// Check if done
		if p.progress.Completed >= p.progress.Total {
			p.progress.Done = true
			p.progress.Current = ""
		}
		p.mu.Unlock()

		p.reportProgress()

		if p.onResult != nil {
			p.onResult(result)
		}
	}
}

// ProcessPendingFiles loads and processes all pending files
func (p *Pool) ProcessPendingFiles(ctx context.Context, batchSize int) error {
	// Load pending files from database
	files, err := p.fileRepo.ListByStatus(database.StatusPending, batchSize, 0)
	if err != nil {
		return fmt.Errorf("failed to load pending files: %w", err)
	}

	if len(files) == 0 {
		p.log("info", "No pending files to process")
		return nil
	}

	p.log("info", fmt.Sprintf("Processing %d pending files", len(files)))

	// Start pool if not already running
	p.Start()
	defer p.Stop()

	// Submit all files
	p.SubmitBatch(files)

	// Wait for completion or context cancellation
	done := make(chan struct{})
	go func() {
		p.Wait()
		close(done)
	}()

	select {
	case <-done:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}
