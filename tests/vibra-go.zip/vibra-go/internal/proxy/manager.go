package proxy

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"net/url"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/net/proxy"
)

// Config holds proxy configuration
type Config struct {
	Enabled         bool   `json:"enabled"`
	Host            string `json:"host"`
	Port            int    `json:"port"`
	Username        string `json:"username"`
	Password        string `json:"password"`
	Type            string `json:"type"` // http, socks5
	RotationURL     string `json:"rotation_url"`
	RotationTimeout int    `json:"rotation_timeout"` // seconds
}

// Manager handles proxy connections and rate limit handling
type Manager struct {
	mu     sync.RWMutex
	config Config

	// Current state
	currentProxy string
	currentIP    string

	// Rate limiting
	rateLimited   atomic.Bool
	rateLimitCh   chan struct{} // Blocks workers when rate limited
	resumeCh      chan struct{} // Signals resume
	retryCount    int
	maxRetries    int
	backoffTimes  []time.Duration

	// HTTP client with proxy
	client *http.Client

	// Event callbacks
	onRateLimited func(paused bool, retryIn time.Duration)
	onIPRotated   func(oldIP, newIP string, success bool)
	onLog         func(level, message string)
}

// NewManager creates a new proxy manager
func NewManager(config Config) *Manager {
	m := &Manager{
		config:       config,
		rateLimitCh:  make(chan struct{}),
		resumeCh:     make(chan struct{}),
		maxRetries:   3,
		backoffTimes: []time.Duration{30 * time.Second, 60 * time.Second, 120 * time.Second},
	}

	// Build proxy URL if enabled
	if config.Enabled && config.Host != "" {
		m.buildProxyURL()
		m.buildClient()
	} else {
		m.client = &http.Client{Timeout: 30 * time.Second}
	}

	return m
}

// SetEventHandlers sets callback functions for events
func (m *Manager) SetEventHandlers(
	onRateLimited func(paused bool, retryIn time.Duration),
	onIPRotated func(oldIP, newIP string, success bool),
	onLog func(level, message string),
) {
	m.onRateLimited = onRateLimited
	m.onIPRotated = onIPRotated
	m.onLog = onLog
}

func (m *Manager) log(level, message string) {
	if m.onLog != nil {
		m.onLog(level, message)
	}
}

// buildProxyURL constructs the proxy URL from config
func (m *Manager) buildProxyURL() {
	var scheme string
	switch m.config.Type {
	case "socks5":
		scheme = "socks5"
	default:
		scheme = "http"
	}

	u := &url.URL{
		Scheme: scheme,
		Host:   fmt.Sprintf("%s:%d", m.config.Host, m.config.Port),
	}

	if m.config.Username != "" {
		u.User = url.UserPassword(m.config.Username, m.config.Password)
	}

	m.currentProxy = u.String()
}

// buildClient creates an HTTP client with the configured proxy
func (m *Manager) buildClient() {
	transport := &http.Transport{}

	if m.config.Type == "socks5" {
		// SOCKS5 proxy
		dialer, err := proxy.SOCKS5("tcp", fmt.Sprintf("%s:%d", m.config.Host, m.config.Port), nil, proxy.Direct)
		if err == nil {
			transport.Dial = dialer.Dial
		}
	} else {
		// HTTP proxy
		proxyURL, err := url.Parse(m.currentProxy)
		if err == nil {
			transport.Proxy = http.ProxyURL(proxyURL)
		}
	}

	m.client = &http.Client{
		Transport: transport,
		Timeout:   30 * time.Second,
	}
}

// GetClient returns the HTTP client configured with proxy
func (m *Manager) GetClient() *http.Client {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.client
}

// GetProxyURL returns the current proxy URL
func (m *Manager) GetProxyURL() string {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.currentProxy
}

// IsEnabled returns whether proxy is enabled
func (m *Manager) IsEnabled() bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.config.Enabled
}

// WaitIfRateLimited blocks until rate limiting is cleared
// Returns error if context is cancelled
func (m *Manager) WaitIfRateLimited(ctx context.Context) error {
	if !m.rateLimited.Load() {
		return nil
	}

	m.log("debug", "Worker waiting for rate limit to clear...")

	select {
	case <-m.resumeCh:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// IsRateLimited returns whether we're currently rate limited
func (m *Manager) IsRateLimited() bool {
	return m.rateLimited.Load()
}

// OnRateLimit handles a 429 rate limit response
// This should be called when any worker receives a 429
func (m *Manager) OnRateLimit(ctx context.Context) error {
	// Only one goroutine should handle rate limiting
	if !m.rateLimited.CompareAndSwap(false, true) {
		// Already being handled, just wait
		return m.WaitIfRateLimited(ctx)
	}

	m.mu.Lock()
	defer m.mu.Unlock()

	m.log("warn", "Rate limited (429) - pausing all workers")

	// Notify event handlers
	if m.onRateLimited != nil {
		m.onRateLimited(true, 0)
	}

	var err error

	if m.config.RotationURL != "" {
		// Rotate proxy IP
		err = m.rotateProxy(ctx)
	} else {
		// Use exponential backoff
		err = m.backoff(ctx)
	}

	// Resume workers
	m.rateLimited.Store(false)
	close(m.resumeCh)
	m.resumeCh = make(chan struct{})

	if m.onRateLimited != nil {
		m.onRateLimited(false, 0)
	}

	return err
}

// rotateProxy calls the rotation URL and waits for the proxy to come back online
func (m *Manager) rotateProxy(ctx context.Context) error {
	oldIP := m.currentIP
	if oldIP == "" {
		oldIP, _ = m.fetchCurrentIP(ctx)
	}

	m.log("info", fmt.Sprintf("Rotating proxy IP (current: %s)...", oldIP))

	// Call rotation URL
	if err := m.callRotationURL(ctx); err != nil {
		m.log("error", fmt.Sprintf("Failed to call rotation URL: %v", err))
		// Continue anyway - the proxy might still rotate
	}

	// Wait random 5-10 seconds for rotation to take effect
	waitTime := time.Duration(5+rand.Intn(6)) * time.Second
	m.log("info", fmt.Sprintf("Waiting %v for rotation to take effect...", waitTime))

	select {
	case <-time.After(waitTime):
	case <-ctx.Done():
		return ctx.Err()
	}

	// Test proxy until it's back online
	timeout := time.Duration(m.config.RotationTimeout) * time.Second
	if timeout == 0 {
		timeout = 60 * time.Second
	}

	deadline := time.Now().Add(timeout)
	testInterval := 3 * time.Second

	for time.Now().Before(deadline) {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		m.log("debug", "Testing proxy connectivity...")
		if m.testProxy(ctx) {
			newIP, _ := m.fetchCurrentIP(ctx)
			m.currentIP = newIP

			if m.onIPRotated != nil {
				m.onIPRotated(oldIP, newIP, true)
			}

			m.log("info", fmt.Sprintf("Proxy IP rotated: %s -> %s", oldIP, newIP))
			m.retryCount = 0
			return nil
		}

		m.log("debug", fmt.Sprintf("Proxy not ready, waiting %v...", testInterval))
		select {
		case <-time.After(testInterval):
		case <-ctx.Done():
			return ctx.Err()
		}
	}

	if m.onIPRotated != nil {
		m.onIPRotated(oldIP, "", false)
	}

	return fmt.Errorf("proxy rotation timeout after %v", timeout)
}

// backoff implements exponential backoff without proxy rotation
func (m *Manager) backoff(ctx context.Context) error {
	if m.retryCount >= m.maxRetries {
		m.log("error", "Max rate limit retries exceeded")
		return fmt.Errorf("max rate limit retries (%d) exceeded", m.maxRetries)
	}

	waitTime := m.backoffTimes[m.retryCount]
	m.retryCount++

	m.log("warn", fmt.Sprintf("Rate limited - backing off for %v (attempt %d/%d)", waitTime, m.retryCount, m.maxRetries))

	if m.onRateLimited != nil {
		m.onRateLimited(true, waitTime)
	}

	select {
	case <-time.After(waitTime):
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// callRotationURL calls the configured rotation URL
func (m *Manager) callRotationURL(ctx context.Context) error {
	req, err := http.NewRequestWithContext(ctx, "GET", m.config.RotationURL, nil)
	if err != nil {
		return err
	}

	// Use direct connection (not through proxy) to call rotation URL
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	return nil
}

// testProxy tests if the proxy is working
func (m *Manager) testProxy(ctx context.Context) bool {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, "GET", "https://api.country.is", nil)
	if err != nil {
		return false
	}

	resp, err := m.client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()

	return resp.StatusCode == 200
}

// fetchCurrentIP fetches the current IP address through the proxy
func (m *Manager) fetchCurrentIP(ctx context.Context) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, "GET", "https://api.country.is", nil)
	if err != nil {
		return "unknown", err
	}

	resp, err := m.client.Do(req)
	if err != nil {
		return "unknown", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "unknown", err
	}

	var result struct {
		IP      string `json:"ip"`
		Country string `json:"country"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return "unknown", err
	}

	return result.IP, nil
}

// TestConnection tests the proxy connection and returns the current IP
func (m *Manager) TestConnection(ctx context.Context) (string, error) {
	if !m.config.Enabled {
		// Direct connection
		return m.fetchDirectIP(ctx)
	}

	return m.fetchCurrentIP(ctx)
}

// fetchDirectIP fetches IP without using proxy
func (m *Manager) fetchDirectIP(ctx context.Context) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, "GET", "https://api.country.is", nil)
	if err != nil {
		return "unknown", err
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "unknown", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "unknown", err
	}

	var result struct {
		IP string `json:"ip"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return "unknown", err
	}

	return result.IP, nil
}

// UpdateConfig updates the proxy configuration
func (m *Manager) UpdateConfig(config Config) {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.config = config
	if config.Enabled && config.Host != "" {
		m.buildProxyURL()
		m.buildClient()
	} else {
		m.currentProxy = ""
		m.client = &http.Client{Timeout: 30 * time.Second}
	}
}

// ResetRetryCount resets the backoff retry counter (call on successful request)
func (m *Manager) ResetRetryCount() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.retryCount = 0
}
