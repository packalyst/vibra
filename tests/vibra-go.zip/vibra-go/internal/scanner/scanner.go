package scanner

import (
	"context"
	"crypto/md5"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"

	"github.com/packalyst/vibra-go/internal/database"
)

// SupportedFormats lists the audio formats we can process
var SupportedFormats = map[string]bool{
	".mp3":  true,
	".wav":  true,
	".flac": true,
	".ogg":  true,
	".m4a":  true,
	".aac":  true,
	".wma":  true,
	".opus": true,
}

// Scanner scans directories for audio files
type Scanner struct {
	fileRepo *database.FileRepository

	// Configuration
	maxFileSize int64 // bytes
	batchSize   int

	// Progress tracking
	progress Progress

	// Event callbacks
	onProgress func(Progress)
	onLog      func(level, message string)
}

// Progress represents scan progress
type Progress struct {
	Total    int64 `json:"total"`
	Scanned  int64 `json:"scanned"`
	Imported int64 `json:"imported"`
	Skipped  int64 `json:"skipped"`
	Errors   int64 `json:"errors"`
	Done     bool  `json:"done"`
}

// NewScanner creates a new scanner
func NewScanner(fileRepo *database.FileRepository) *Scanner {
	return &Scanner{
		fileRepo:    fileRepo,
		maxFileSize: 500 * 1024 * 1024, // 500 MB default
		batchSize:   100,
	}
}

// SetMaxFileSize sets the maximum file size to process
func (s *Scanner) SetMaxFileSize(bytes int64) {
	s.maxFileSize = bytes
}

// SetBatchSize sets the batch size for database inserts
func (s *Scanner) SetBatchSize(size int) {
	s.batchSize = size
}

// SetProgressHandler sets the progress callback
func (s *Scanner) SetProgressHandler(handler func(Progress)) {
	s.onProgress = handler
}

// SetLogHandler sets the logging callback
func (s *Scanner) SetLogHandler(handler func(level, message string)) {
	s.onLog = handler
}

func (s *Scanner) log(level, message string) {
	if s.onLog != nil {
		s.onLog(level, message)
	}
}

func (s *Scanner) reportProgress() {
	if s.onProgress != nil {
		s.onProgress(s.progress)
	}
}

// Scan scans a directory for audio files and imports them
func (s *Scanner) Scan(ctx context.Context, dir string) error {
	s.progress = Progress{}

	// Verify directory exists
	info, err := os.Stat(dir)
	if err != nil {
		return fmt.Errorf("cannot access directory: %w", err)
	}
	if !info.IsDir() {
		return fmt.Errorf("not a directory: %s", dir)
	}

	s.log("info", fmt.Sprintf("Scanning directory: %s", dir))

	// First pass: count files
	err = filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // Skip errors
		}
		if !info.IsDir() && s.isSupportedFormat(path) {
			atomic.AddInt64(&s.progress.Total, 1)
		}
		return nil
	})
	if err != nil {
		return err
	}

	s.log("info", fmt.Sprintf("Found %d audio files", s.progress.Total))
	s.reportProgress()

	// Second pass: process files
	var batch []*database.File
	var batchMu sync.Mutex

	err = filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		if err != nil {
			s.log("warn", fmt.Sprintf("Error accessing %s: %v", path, err))
			return nil
		}

		if info.IsDir() {
			return nil
		}

		if !s.isSupportedFormat(path) {
			return nil
		}

		atomic.AddInt64(&s.progress.Scanned, 1)

		// Check file size
		if info.Size() > s.maxFileSize {
			s.log("debug", fmt.Sprintf("Skipping large file: %s (%d MB)", path, info.Size()/(1024*1024)))
			atomic.AddInt64(&s.progress.Skipped, 1)
			s.reportProgress()
			return nil
		}

		// Check if already exists
		existing, _ := s.fileRepo.GetByPath(path)
		if existing != nil {
			atomic.AddInt64(&s.progress.Skipped, 1)
			s.reportProgress()
			return nil
		}

		// Create file record
		file := &database.File{
			Path:     path,
			Status:   database.StatusPending,
			Source:   "local",
			FileSize: info.Size(),
		}

		// Generate hash (for deduplication)
		hash, err := s.hashFile(path)
		if err == nil {
			file.Hash = hash

			// Check for duplicate by hash
			dup, _ := s.fileRepo.GetByHash(hash)
			if dup != nil {
				s.log("debug", fmt.Sprintf("Duplicate file (hash): %s", path))
				atomic.AddInt64(&s.progress.Skipped, 1)
				s.reportProgress()
				return nil
			}
		}

		batchMu.Lock()
		batch = append(batch, file)
		if len(batch) >= s.batchSize {
			if err := s.saveBatch(batch); err != nil {
				s.log("error", fmt.Sprintf("Failed to save batch: %v", err))
				atomic.AddInt64(&s.progress.Errors, int64(len(batch)))
			} else {
				atomic.AddInt64(&s.progress.Imported, int64(len(batch)))
			}
			batch = batch[:0]
			s.reportProgress()
		}
		batchMu.Unlock()

		return nil
	})

	if err != nil {
		return err
	}

	// Save remaining batch
	if len(batch) > 0 {
		if err := s.saveBatch(batch); err != nil {
			s.log("error", fmt.Sprintf("Failed to save final batch: %v", err))
			atomic.AddInt64(&s.progress.Errors, int64(len(batch)))
		} else {
			atomic.AddInt64(&s.progress.Imported, int64(len(batch)))
		}
	}

	s.progress.Done = true
	s.reportProgress()

	s.log("info", fmt.Sprintf("Scan complete: %d imported, %d skipped, %d errors",
		s.progress.Imported, s.progress.Skipped, s.progress.Errors))

	return nil
}

func (s *Scanner) isSupportedFormat(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return SupportedFormats[ext]
}

func (s *Scanner) hashFile(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	// For large files, only hash first 10MB for performance
	const maxHashSize = 10 * 1024 * 1024

	info, _ := f.Stat()
	h := md5.New()

	if info.Size() > maxHashSize {
		// Hash first chunk
		io.CopyN(h, f, maxHashSize/2)
		// Seek to end and hash last chunk
		f.Seek(-maxHashSize/2, io.SeekEnd)
		io.CopyN(h, f, maxHashSize/2)
	} else {
		io.Copy(h, f)
	}

	return fmt.Sprintf("%x", h.Sum(nil)), nil
}

func (s *Scanner) saveBatch(batch []*database.File) error {
	for _, file := range batch {
		if err := s.fileRepo.Create(file); err != nil {
			return err
		}
	}
	return nil
}

// GetProgress returns the current scan progress
func (s *Scanner) GetProgress() Progress {
	return s.progress
}
