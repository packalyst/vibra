package recognition

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os/exec"
	"strings"
	"time"

	"github.com/packalyst/vibra-go/internal/fingerprint"
	"github.com/packalyst/vibra-go/internal/proxy"
	"github.com/packalyst/vibra-go/pkg/metadata"
)

const (
	shazamAPIURL = "https://amp.shazam.com/discovery/v5/fr/FR/android/-/tag/"
)

// ShazamService handles Shazam recognition
type ShazamService struct {
	proxyMgr *proxy.Manager
	timeout  time.Duration
	onLog    func(level, message string)
}

// NewShazamService creates a new Shazam service
func NewShazamService(proxyMgr *proxy.Manager, timeout time.Duration) *ShazamService {
	return &ShazamService{
		proxyMgr: proxyMgr,
		timeout:  timeout,
	}
}

// SetLogHandler sets the logging callback
func (s *ShazamService) SetLogHandler(handler func(level, message string)) {
	s.onLog = handler
}

// ShazamResponse represents the Shazam API response
type ShazamResponse struct {
	Matches []struct {
		ID            string  `json:"id"`
		Offset        float64 `json:"offset"`
		TimeSkew      float64 `json:"timeskew"`
		FrequencySkew float64 `json:"frequencyskew"`
	} `json:"matches"`
	Track *ShazamTrack `json:"track"`
}

// ShazamTrack represents track data from Shazam
type ShazamTrack struct {
	Layout   string `json:"layout"`
	Type     string `json:"type"`
	Key      string `json:"key"`
	Title    string `json:"title"`
	Subtitle string `json:"subtitle"`
	Share    struct {
		Subject string `json:"subject"`
		Text    string `json:"text"`
		Href    string `json:"href"`
		Image   string `json:"image"`
	} `json:"share"`
	Images struct {
		Background string `json:"background"`
		Coverart   string `json:"coverart"`
		CoverartHQ string `json:"coverarthq"`
	} `json:"images"`
	Hub struct {
		Type    string `json:"type"`
		Actions []struct {
			Name string `json:"name"`
			Type string `json:"type"`
			ID   string `json:"id"`
			URI  string `json:"uri"`
		} `json:"actions"`
		Providers []struct {
			Caption string `json:"caption"`
			Type    string `json:"type"`
			Actions []struct {
				Name string `json:"name"`
				Type string `json:"type"`
				URI  string `json:"uri"`
			} `json:"actions"`
		} `json:"providers"`
	} `json:"hub"`
	Sections []struct {
		Type     string `json:"type"`
		Metadata []struct {
			Title string `json:"title"`
			Text  string `json:"text"`
		} `json:"metadata"`
	} `json:"sections"`
	ISRC   string   `json:"isrc"`
	Genres struct {
		Primary string `json:"primary"`
	} `json:"genres"`
}

// Recognize attempts to identify a song using Shazam via vibra-cli
func (s *ShazamService) Recognize(ctx context.Context, filePath string) (*metadata.Unified, error) {
	// Log the file we're processing
	if s.onLog != nil {
		s.onLog("info", fmt.Sprintf("[Shazam] Processing: %s", filePath))
	}

	// Use vibra-cli for recognition (it handles the API call correctly)
	return s.recognizeWithCLI(ctx, filePath)
}

// recognizeWithCLI uses vibra-cli for recognition
func (s *ShazamService) recognizeWithCLI(ctx context.Context, filePath string) (*metadata.Unified, error) {
	if s.onLog != nil {
		s.onLog("debug", "[Shazam] Using vibra-cli for recognition...")
	}

	// Run vibra-cli recognize command
	cmd := exec.CommandContext(ctx, "vibra-cli", "-R", "-f", filePath)
	output, err := cmd.Output()
	if err != nil {
		if s.onLog != nil {
			s.onLog("error", fmt.Sprintf("[Shazam] vibra-cli failed: %v", err))
		}
		return nil, fmt.Errorf("vibra-cli failed: %w", err)
	}

	// Parse JSON response
	var shazamResp ShazamResponse
	if err := json.Unmarshal(output, &shazamResp); err != nil {
		if s.onLog != nil {
			s.onLog("error", fmt.Sprintf("[Shazam] Failed to parse response: %v", err))
		}
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	// Check if we got a match
	if shazamResp.Track == nil || len(shazamResp.Matches) == 0 {
		if s.onLog != nil {
			s.onLog("info", "[Shazam] No match found")
		}
		return nil, ErrNoMatch
	}

	if s.onLog != nil {
		s.onLog("info", fmt.Sprintf("[Shazam] Match: %s - %s", shazamResp.Track.Subtitle, shazamResp.Track.Title))
	}

	return s.convertToMetadata(&shazamResp), nil
}

// RecognizeFromFingerprint recognizes using a pre-generated fingerprint
func (s *ShazamService) RecognizeFromFingerprint(ctx context.Context, fp *fingerprint.Fingerprint) (*metadata.Unified, error) {
	return s.recognizeWithFingerprint(ctx, fp)
}

func (s *ShazamService) recognizeWithFingerprint(ctx context.Context, fp *fingerprint.Fingerprint) (*metadata.Unified, error) {
	// Build request body matching vibra CLI format
	timestamp := time.Now().UnixMilli()

	// Random geolocation (European coordinates)
	lat := 45.0 + (float64(time.Now().UnixNano()%1000) / 1000.0 * 20.0)
	lon := 10.0 + (float64(time.Now().UnixNano()%1000) / 1000.0 * 30.0)
	alt := 100.0 + (float64(time.Now().UnixNano()%1000) / 1000.0 * 400.0)

	// Compact JSON like vibra CLI
	body := fmt.Sprintf(`{"geolocation":{"altitude":%.2f,"latitude":%.2f,"longitude":%.2f},"signature":{"samplems":%d,"timestamp":%d,"uri":"%s"},"timestamp":%d,"timezone":"Europe/Paris"}`,
		alt, lat, lon, fp.SampleMS, timestamp, fp.URI, timestamp)

	if s.onLog != nil {
		s.onLog("debug", fmt.Sprintf("[Shazam] URL: %s", shazamAPIURL))
		s.onLog("debug", fmt.Sprintf("[Shazam] Body: %s", body))
	}

	// Create request
	ctx, cancel := context.WithTimeout(ctx, s.timeout)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, "POST", shazamAPIURL, bytes.NewBufferString(body))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Accept-Encoding", "gzip, deflate, br")
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Connection", "keep-alive")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Content-Language", "en_US")
	req.Header.Set("User-Agent", getRandomUserAgent())

	// Get HTTP client (with proxy if configured)
	client := s.proxyMgr.GetClient()

	// Make request
	resp, err := client.Do(req)
	if err != nil {
		if s.onLog != nil {
			s.onLog("error", fmt.Sprintf("[Shazam] Request failed: %v", err))
		}
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if s.onLog != nil {
		s.onLog("debug", fmt.Sprintf("[Shazam] Response status: %d", resp.StatusCode))
	}

	// Check for rate limiting
	if resp.StatusCode == 429 {
		if s.onLog != nil {
			s.onLog("warn", "[Shazam] Rate limited (429)")
		}
		return nil, ErrRateLimited
	}

	if resp.StatusCode != 200 {
		bodyBytes, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("unexpected status %d: %s", resp.StatusCode, string(bodyBytes))
	}

	// Parse response
	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	var shazamResp ShazamResponse
	if err := json.Unmarshal(respBody, &shazamResp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	// Check if we got a match
	if shazamResp.Track == nil || len(shazamResp.Matches) == 0 {
		if s.onLog != nil {
			s.onLog("info", "[Shazam] No match found")
		}
		return nil, ErrNoMatch
	}

	if s.onLog != nil {
		s.onLog("info", fmt.Sprintf("[Shazam] Match: %s - %s", shazamResp.Track.Subtitle, shazamResp.Track.Title))
	}

	// Convert to unified metadata
	return s.convertToMetadata(&shazamResp), nil
}

func (s *ShazamService) convertToMetadata(resp *ShazamResponse) *metadata.Unified {
	track := resp.Track
	m := metadata.NewUnified()

	m.Service = "shazam"
	m.Confidence = 0.95 // Shazam is generally very accurate

	// Basic info
	m.Title = track.Title
	m.Artist = track.Subtitle // Shazam puts artist in subtitle
	m.ShazamID = track.Key
	m.ISRC = track.ISRC

	// Genre
	m.Genre = track.Genres.Primary

	// Artwork
	m.ArtworkURL = track.Images.Coverart
	m.ArtworkURLHQ = track.Images.CoverartHQ

	// Links
	m.ShazamURL = track.Share.Href

	// Extract additional info from sections
	for _, section := range track.Sections {
		if section.Type == "SONG" {
			for _, meta := range section.Metadata {
				switch meta.Title {
				case "Album":
					m.Album = meta.Text
				case "Released":
					m.ReleaseDate = meta.Text
				case "Label":
					m.Label = meta.Text
				}
			}
		}
	}

	// Extract Apple Music / Spotify links from hub
	for _, provider := range track.Hub.Providers {
		for _, action := range provider.Actions {
			if strings.Contains(action.URI, "apple") {
				m.AppleMusicURL = action.URI
			} else if strings.Contains(action.URI, "spotify") {
				m.SpotifyURL = action.URI
			}
		}
	}

	// Extract preview URL
	for _, action := range track.Hub.Actions {
		if action.Type == "uri" && strings.Contains(action.URI, "audio") {
			m.PreviewURL = action.URI
			break
		}
	}

	return m
}

// Name returns the service name
func (s *ShazamService) Name() string {
	return "shazam"
}

// User agents for rotation (Android Dalvik like vibra CLI)
var userAgents = []string{
	"Dalvik/2.1.0 (Linux; U; Android 6.0.1; SM-G920F Build/MMB29K)",
	"Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-N910G Build/LMY47X)",
	"Dalvik/2.1.0 (Linux; U; Android 6.0.1; SM-G930F Build/MMB29K)",
	"Dalvik/2.1.0 (Linux; U; Android 5.0; SM-G900F Build/LRX21T)",
}

func getRandomUserAgent() string {
	return userAgents[time.Now().UnixNano()%int64(len(userAgents))]
}
