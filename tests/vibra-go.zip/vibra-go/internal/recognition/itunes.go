package recognition

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/packalyst/vibra-go/pkg/metadata"
)

const (
	itunesSearchURL = "https://itunes.apple.com/search"
)

// ITunesService handles iTunes metadata enrichment
type ITunesService struct {
	timeout time.Duration
	client  *http.Client
}

// NewITunesService creates a new iTunes service
func NewITunesService(timeout time.Duration) *ITunesService {
	return &ITunesService{
		timeout: timeout,
		client:  &http.Client{Timeout: timeout},
	}
}

// ITunesResponse represents the iTunes API response
type ITunesResponse struct {
	ResultCount int            `json:"resultCount"`
	Results     []ITunesResult `json:"results"`
}

// ITunesResult represents a single iTunes search result
type ITunesResult struct {
	WrapperType            string  `json:"wrapperType"`
	Kind                   string  `json:"kind"`
	TrackID                int64   `json:"trackId"`
	ArtistID               int64   `json:"artistId"`
	CollectionID           int64   `json:"collectionId"`
	ArtistName             string  `json:"artistName"`
	CollectionName         string  `json:"collectionName"`
	TrackName              string  `json:"trackName"`
	CollectionCensoredName string  `json:"collectionCensoredName"`
	TrackCensoredName      string  `json:"trackCensoredName"`
	ArtistViewURL          string  `json:"artistViewUrl"`
	CollectionViewURL      string  `json:"collectionViewUrl"`
	TrackViewURL           string  `json:"trackViewUrl"`
	PreviewURL             string  `json:"previewUrl"`
	ArtworkURL30           string  `json:"artworkUrl30"`
	ArtworkURL60           string  `json:"artworkUrl60"`
	ArtworkURL100          string  `json:"artworkUrl100"`
	CollectionPrice        float64 `json:"collectionPrice"`
	TrackPrice             float64 `json:"trackPrice"`
	ReleaseDate            string  `json:"releaseDate"`
	CollectionExplicitness string  `json:"collectionExplicitness"`
	TrackExplicitness      string  `json:"trackExplicitness"`
	DiscCount              int     `json:"discCount"`
	DiscNumber             int     `json:"discNumber"`
	TrackCount             int     `json:"trackCount"`
	TrackNumber            int     `json:"trackNumber"`
	TrackTimeMillis        int64   `json:"trackTimeMillis"`
	Country                string  `json:"country"`
	Currency               string  `json:"currency"`
	PrimaryGenreName       string  `json:"primaryGenreName"`
	IsStreamable           bool    `json:"isStreamable"`
}

// Recognize searches iTunes for a song (requires artist and title)
func (s *ITunesService) Recognize(ctx context.Context, filePath string) (*metadata.Unified, error) {
	// iTunes doesn't do audio recognition - it needs search terms
	// This is used for enrichment after Shazam/AcoustID
	return nil, ErrNoMatch
}

// Search searches iTunes for a song by artist and title
func (s *ITunesService) Search(ctx context.Context, artist, title string) (*metadata.Unified, error) {
	if artist == "" && title == "" {
		return nil, ErrNoMatch
	}

	// Build search query
	query := strings.TrimSpace(artist + " " + title)
	params := url.Values{
		"term":   {query},
		"media":  {"music"},
		"entity": {"song"},
		"limit":  {"5"},
	}

	ctx, cancel := context.WithTimeout(ctx, s.timeout)
	defer cancel()

	reqURL := itunesSearchURL + "?" + params.Encode()
	req, err := http.NewRequestWithContext(ctx, "GET", reqURL, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := s.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == 429 {
		return nil, ErrRateLimited
	}

	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("unexpected status: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	var itunesResp ITunesResponse
	if err := json.Unmarshal(body, &itunesResp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	if itunesResp.ResultCount == 0 {
		return nil, ErrNoMatch
	}

	// Find best match
	bestMatch := s.findBestMatch(itunesResp.Results, artist, title)
	if bestMatch == nil {
		return nil, ErrNoMatch
	}

	return s.convertToMetadata(bestMatch), nil
}

func (s *ITunesService) findBestMatch(results []ITunesResult, artist, title string) *ITunesResult {
	artistLower := strings.ToLower(artist)
	titleLower := strings.ToLower(title)

	var bestMatch *ITunesResult
	bestScore := 0

	for i := range results {
		result := &results[i]
		if result.Kind != "song" {
			continue
		}

		score := 0

		// Artist match
		if strings.Contains(strings.ToLower(result.ArtistName), artistLower) {
			score += 2
		}

		// Title match
		if strings.Contains(strings.ToLower(result.TrackName), titleLower) {
			score += 2
		}

		// Exact match bonus
		if strings.EqualFold(result.ArtistName, artist) {
			score += 1
		}
		if strings.EqualFold(result.TrackName, title) {
			score += 1
		}

		if score > bestScore {
			bestScore = score
			bestMatch = result
		}
	}

	if bestScore < 2 {
		return nil
	}

	return bestMatch
}

func (s *ITunesService) convertToMetadata(result *ITunesResult) *metadata.Unified {
	m := metadata.NewUnified()
	m.Service = "itunes"
	m.Confidence = 0.7 // Lower than audio fingerprint

	m.Title = result.TrackName
	m.Artist = result.ArtistName
	m.Album = result.CollectionName
	m.Genre = result.PrimaryGenreName
	m.TrackNumber = result.TrackNumber
	m.DiscNumber = result.DiscNumber

	// Parse year from release date
	if len(result.ReleaseDate) >= 4 {
		fmt.Sscanf(result.ReleaseDate[:4], "%d", &m.Year)
	}
	m.ReleaseDate = result.ReleaseDate

	// Duration
	m.Duration = float64(result.TrackTimeMillis) / 1000.0

	// IDs
	m.ITunesID = fmt.Sprintf("%d", result.TrackID)

	// Artwork - get highest resolution
	m.ArtworkURL = result.ArtworkURL100
	// iTunes can provide higher resolution by modifying URL
	if result.ArtworkURL100 != "" {
		m.ArtworkURLHQ = strings.Replace(result.ArtworkURL100, "100x100", "600x600", 1)
	}

	// Links
	m.AppleMusicURL = result.TrackViewURL
	m.PreviewURL = result.PreviewURL

	return m
}

// Enrich enriches existing metadata with iTunes data
func (s *ITunesService) Enrich(ctx context.Context, m *metadata.Unified) error {
	if m.Artist == "" || m.Title == "" {
		return nil
	}

	enriched, err := s.Search(ctx, m.Artist, m.Title)
	if err != nil {
		return err
	}

	m.Merge(enriched, 0)
	return nil
}

// Name returns the service name
func (s *ITunesService) Name() string {
	return "itunes"
}
