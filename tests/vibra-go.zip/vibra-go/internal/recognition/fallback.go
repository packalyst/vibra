package recognition

import (
	"context"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/dhowden/tag"
	"github.com/packalyst/vibra-go/pkg/metadata"
)

// FallbackService extracts metadata from filename and existing tags
type FallbackService struct{}

// NewFallbackService creates a new fallback service
func NewFallbackService() *FallbackService {
	return &FallbackService{}
}

// Recognize attempts to extract metadata from file
func (s *FallbackService) Recognize(ctx context.Context, filePath string) (*metadata.Unified, error) {
	m := metadata.NewUnified()
	m.Service = "fallback"
	m.Confidence = 0.3 // Low confidence since it's just parsing

	// Try to read existing tags first
	if err := s.readTags(filePath, m); err == nil && m.IsComplete() {
		m.Confidence = 0.5 // Slightly higher if we got tags
		return m, nil
	}

	// Fall back to filename parsing
	s.parseFilename(filePath, m)

	if !m.IsComplete() {
		return nil, ErrNoMatch
	}

	return m, nil
}

// readTags reads metadata from existing file tags
func (s *FallbackService) readTags(filePath string, m *metadata.Unified) error {
	f, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer f.Close()

	tags, err := tag.ReadFrom(f)
	if err != nil {
		return err
	}

	if title := tags.Title(); title != "" {
		m.Title = title
	}
	if artist := tags.Artist(); artist != "" {
		m.Artist = artist
	}
	if album := tags.Album(); album != "" {
		m.Album = album
	}
	if year := tags.Year(); year > 0 {
		m.Year = year
	}
	if genre := tags.Genre(); genre != "" {
		m.Genre = genre
	}

	track, _ := tags.Track()
	if track > 0 {
		m.TrackNumber = track
	}

	disc, _ := tags.Disc()
	if disc > 0 {
		m.DiscNumber = disc
	}

	return nil
}

// Common filename patterns
var filenamePatterns = []*regexp.Regexp{
	// "Artist - Title.mp3"
	regexp.MustCompile(`^(.+?)\s*-\s*(.+)$`),
	// "01 - Artist - Title.mp3" or "01. Artist - Title.mp3"
	regexp.MustCompile(`^\d+[\.\s\-]+(.+?)\s*-\s*(.+)$`),
	// "Artist_-_Title.mp3"
	regexp.MustCompile(`^(.+?)_-_(.+)$`),
	// "01 Title.mp3"
	regexp.MustCompile(`^\d+[\.\s]+(.+)$`),
}

// parseFilename extracts artist and title from filename
func (s *FallbackService) parseFilename(filePath string, m *metadata.Unified) {
	// Get filename without extension
	filename := filepath.Base(filePath)
	ext := filepath.Ext(filename)
	name := strings.TrimSuffix(filename, ext)

	// Clean up common noise
	name = cleanFilename(name)

	// Try each pattern
	for _, pattern := range filenamePatterns {
		matches := pattern.FindStringSubmatch(name)
		if len(matches) >= 3 {
			m.Artist = strings.TrimSpace(matches[1])
			m.Title = strings.TrimSpace(matches[2])
			return
		} else if len(matches) == 2 {
			// Only title matched (e.g., "01 Title.mp3")
			m.Title = strings.TrimSpace(matches[1])
			return
		}
	}

	// No pattern matched, use whole name as title
	m.Title = name
}

// cleanFilename removes common noise from filename
func cleanFilename(name string) string {
	// Remove common suffixes
	suffixes := []string{
		"(Official Video)", "(Official Audio)", "(Official Music Video)",
		"(Lyric Video)", "(Lyrics)", "(Audio)", "(HD)", "(HQ)",
		"[Official Video]", "[Official Audio]", "[HD]", "[HQ]",
		"(128)", "(320)", "(256)", // Bitrate indicators
		"_128", "_320", "_256",
	}

	for _, suffix := range suffixes {
		name = strings.Replace(name, suffix, "", -1)
	}

	// Remove quality tags
	qualityPatterns := []string{
		`\s*\[\d+kbps\]`,
		`\s*\(\d+kbps\)`,
		`\s*-\s*\d+kbps`,
	}

	for _, pattern := range qualityPatterns {
		re := regexp.MustCompile(pattern)
		name = re.ReplaceAllString(name, "")
	}

	// Clean up multiple spaces and underscores
	name = strings.ReplaceAll(name, "_", " ")
	name = regexp.MustCompile(`\s+`).ReplaceAllString(name, " ")

	return strings.TrimSpace(name)
}

// Name returns the service name
func (s *FallbackService) Name() string {
	return "fallback"
}
