package recognition

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"

	"github.com/packalyst/vibra-go/internal/fingerprint"
	"github.com/packalyst/vibra-go/pkg/metadata"
)

const (
	acoustidAPIURL     = "https://api.acoustid.org/v2/lookup"
	musicBrainzAPIURL  = "https://musicbrainz.org/ws/2"
)

// AcoustIDService handles AcoustID recognition
type AcoustIDService struct {
	apiKey  string
	timeout time.Duration
	client  *http.Client
}

// NewAcoustIDService creates a new AcoustID service
func NewAcoustIDService(apiKey string, timeout time.Duration) *AcoustIDService {
	return &AcoustIDService{
		apiKey:  apiKey,
		timeout: timeout,
		client:  &http.Client{Timeout: timeout},
	}
}

// AcoustIDResponse represents the AcoustID API response
type AcoustIDResponse struct {
	Status  string `json:"status"`
	Results []struct {
		ID         string  `json:"id"`
		Score      float64 `json:"score"`
		Recordings []struct {
			ID       string `json:"id"`
			Title    string `json:"title"`
			Duration int    `json:"duration"`
			Artists  []struct {
				ID   string `json:"id"`
				Name string `json:"name"`
			} `json:"artists"`
			ReleaseGroups []struct {
				ID            string `json:"id"`
				Title         string `json:"title"`
				Type          string `json:"type"`
				SecondaryTypes []string `json:"secondarytypes"`
				Releases      []struct {
					ID      string `json:"id"`
					Title   string `json:"title"`
					Country string `json:"country"`
					Date    struct {
						Year  int `json:"year"`
						Month int `json:"month"`
						Day   int `json:"day"`
					} `json:"date"`
				} `json:"releases"`
			} `json:"releasegroups"`
		} `json:"recordings"`
	} `json:"results"`
	Error struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

// Recognize attempts to identify a song using AcoustID
func (s *AcoustIDService) Recognize(ctx context.Context, filePath string) (*metadata.Unified, error) {
	// Generate chromaprint fingerprint
	fp, err := fingerprint.GetChromaprint(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to generate chromaprint: %w", err)
	}

	// Build request
	params := url.Values{
		"client":      {s.apiKey},
		"fingerprint": {fp.Fingerprint},
		"duration":    {fmt.Sprintf("%.0f", fp.Duration)},
		"meta":        {"recordings+releasegroups+compress"},
		"format":      {"json"},
	}

	ctx, cancel := context.WithTimeout(ctx, s.timeout)
	defer cancel()

	reqURL := acoustidAPIURL + "?" + params.Encode()
	req, err := http.NewRequestWithContext(ctx, "GET", reqURL, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("User-Agent", "Vibra/1.0")

	resp, err := s.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode == 429 {
		return nil, ErrRateLimited
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	var acoustidResp AcoustIDResponse
	if err := json.Unmarshal(body, &acoustidResp); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	if acoustidResp.Status == "error" {
		return nil, fmt.Errorf("AcoustID error: %s", acoustidResp.Error.Message)
	}

	// Find best match
	if len(acoustidResp.Results) == 0 {
		return nil, ErrNoMatch
	}

	bestResult := acoustidResp.Results[0]
	if len(bestResult.Recordings) == 0 {
		return nil, ErrNoMatch
	}

	// Convert to unified metadata
	return s.convertToMetadata(&bestResult), nil
}

func (s *AcoustIDService) convertToMetadata(result *struct {
	ID         string  `json:"id"`
	Score      float64 `json:"score"`
	Recordings []struct {
		ID       string `json:"id"`
		Title    string `json:"title"`
		Duration int    `json:"duration"`
		Artists  []struct {
			ID   string `json:"id"`
			Name string `json:"name"`
		} `json:"artists"`
		ReleaseGroups []struct {
			ID            string `json:"id"`
			Title         string `json:"title"`
			Type          string `json:"type"`
			SecondaryTypes []string `json:"secondarytypes"`
			Releases      []struct {
				ID      string `json:"id"`
				Title   string `json:"title"`
				Country string `json:"country"`
				Date    struct {
					Year  int `json:"year"`
					Month int `json:"month"`
					Day   int `json:"day"`
				} `json:"date"`
			} `json:"releases"`
		} `json:"releasegroups"`
	} `json:"recordings"`
}) *metadata.Unified {
	m := metadata.NewUnified()
	m.Service = "acoustid"
	m.Confidence = result.Score

	if len(result.Recordings) == 0 {
		return m
	}

	recording := result.Recordings[0]
	m.Title = recording.Title
	m.MusicBrainzID = recording.ID
	m.Duration = float64(recording.Duration)

	// Artist
	if len(recording.Artists) > 0 {
		m.Artist = recording.Artists[0].Name

		// Additional artists as featured
		if len(recording.Artists) > 1 {
			for _, artist := range recording.Artists[1:] {
				m.FeatArtists = append(m.FeatArtists, artist.Name)
			}
		}
	}

	// Release/Album info
	if len(recording.ReleaseGroups) > 0 {
		rg := recording.ReleaseGroups[0]
		m.Album = rg.Title

		// Get year from first release
		if len(rg.Releases) > 0 {
			release := rg.Releases[0]
			if release.Date.Year > 0 {
				m.Year = release.Date.Year
			}
		}
	}

	return m
}

// Name returns the service name
func (s *AcoustIDService) Name() string {
	return "acoustid"
}
