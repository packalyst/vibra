package recognition

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"sync"

	"github.com/packalyst/vibra-go/internal/database"
	"github.com/packalyst/vibra-go/pkg/metadata"
)

// BulkProgress represents the current progress of bulk analysis
type BulkProgress struct {
	Total       int     `json:"total"`
	Processed   int     `json:"processed"`
	OK          int     `json:"ok"`
	Failed      int     `json:"failed"`
	RateLimited int     `json:"rate_limited"`
	Current     string  `json:"current"`
	Done        bool    `json:"done"`
	Percent     float64 `json:"percent"`
}

// BulkResult represents a single file result from bulk analysis
type BulkResult struct {
	File     string          `json:"file"`
	Success  bool            `json:"success"`
	IP       string          `json:"ip"`
	Error    string          `json:"error,omitempty"`
	Response json.RawMessage `json:"response,omitempty"`
}

// BulkOutput represents the complete output from vibra-cli bulk mode
type BulkOutput struct {
	Results []BulkResult `json:"results"`
}

// ShazamBulkResponse represents the nested response structure
type ShazamBulkResponse struct {
	Track *ShazamTrack `json:"track"`
}

// BulkAnalyzer handles bulk recognition using vibra-cli
type BulkAnalyzer struct {
	outputDir string
	threads   int
	delay     int // seconds between files
	fileRepo  *database.FileRepository

	mu       sync.RWMutex
	progress BulkProgress
	running  bool

	onLog      func(level, message string)
	onProgress func(BulkProgress)
}

// NewBulkAnalyzer creates a new bulk analyzer
func NewBulkAnalyzer(outputDir string, threads, delay int, fileRepo *database.FileRepository) *BulkAnalyzer {
	return &BulkAnalyzer{
		outputDir: outputDir,
		threads:   threads,
		delay:     delay,
		fileRepo:  fileRepo,
	}
}

// SetLogHandler sets the logging callback
func (b *BulkAnalyzer) SetLogHandler(handler func(level, message string)) {
	b.onLog = handler
}

// SetProgressHandler sets the progress callback
func (b *BulkAnalyzer) SetProgressHandler(handler func(BulkProgress)) {
	b.onProgress = handler
}

func (b *BulkAnalyzer) log(level, message string) {
	if b.onLog != nil {
		b.onLog(level, message)
	}
}

func (b *BulkAnalyzer) reportProgress() {
	b.mu.RLock()
	prog := b.progress
	b.mu.RUnlock()

	if b.onProgress != nil {
		b.onProgress(prog)
	}
}

// IsRunning returns whether bulk analysis is currently running
func (b *BulkAnalyzer) IsRunning() bool {
	b.mu.RLock()
	defer b.mu.RUnlock()
	return b.running
}

// GetProgress returns the current progress
func (b *BulkAnalyzer) GetProgress() BulkProgress {
	b.mu.RLock()
	defer b.mu.RUnlock()
	return b.progress
}

// AnalyzeDirectory runs vibra-cli bulk mode on a directory
func (b *BulkAnalyzer) AnalyzeDirectory(ctx context.Context, dir string) error {
	b.mu.Lock()
	if b.running {
		b.mu.Unlock()
		return fmt.Errorf("bulk analysis already running")
	}
	b.running = true
	b.progress = BulkProgress{}
	b.mu.Unlock()

	defer func() {
		b.mu.Lock()
		b.running = false
		b.progress.Done = true
		b.mu.Unlock()
		b.reportProgress()
	}()

	outputFile := fmt.Sprintf("%s/results.json", b.outputDir)

	// Build command
	args := []string{
		"-B",
		"-d", dir,
		"-t", strconv.Itoa(b.threads),
		"-w", strconv.Itoa(b.delay),
		"-o", outputFile,
	}

	b.log("info", fmt.Sprintf("[Bulk] Starting: vibra-cli %s", strings.Join(args, " ")))

	cmd := exec.CommandContext(ctx, "vibra-cli", args...)

	// Capture stderr for progress
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return fmt.Errorf("failed to get stderr pipe: %w", err)
	}

	// Start the command
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("failed to start vibra-cli: %w", err)
	}

	// Parse progress from stderr
	progressRegex := regexp.MustCompile(`\]\s*([\d.]+)%\s*\((\d+)/(\d+)\)\s*OK:(\d+)\s*FAIL:(\d+)`)
	rateLimitRegex := regexp.MustCompile(`RATE LIMITED`)

	scanner := bufio.NewScanner(stderr)
	scanner.Split(scanProgress) // Custom split to handle carriage returns

	for scanner.Scan() {
		line := scanner.Text()

		// Check for rate limit
		if rateLimitRegex.MatchString(line) {
			b.log("warn", "[Bulk] Rate limited, vibra-cli is pausing...")
			continue
		}

		// Parse progress bar
		if matches := progressRegex.FindStringSubmatch(line); len(matches) >= 6 {
			percent, _ := strconv.ParseFloat(matches[1], 64)
			processed, _ := strconv.Atoi(matches[2])
			total, _ := strconv.Atoi(matches[3])
			ok, _ := strconv.Atoi(matches[4])
			failed, _ := strconv.Atoi(matches[5])

			b.mu.Lock()
			b.progress.Percent = percent
			b.progress.Processed = processed
			b.progress.Total = total
			b.progress.OK = ok
			b.progress.Failed = failed
			b.mu.Unlock()

			b.reportProgress()
		}
	}

	// Wait for command to finish
	if err := cmd.Wait(); err != nil {
		// Check if context was cancelled
		if ctx.Err() != nil {
			return ctx.Err()
		}
		b.log("error", fmt.Sprintf("[Bulk] vibra-cli exited with error: %v", err))
		// Continue to parse results even if there was an error
	}

	// Parse results file
	b.log("info", "[Bulk] Parsing results...")
	if err := b.parseResultsAndUpdate(outputFile); err != nil {
		return fmt.Errorf("failed to parse results: %w", err)
	}

	b.log("info", fmt.Sprintf("[Bulk] Complete: %d matched, %d failed", b.progress.OK, b.progress.Failed))
	return nil
}

// Custom scanner to handle carriage return progress updates
func scanProgress(data []byte, atEOF bool) (advance int, token []byte, err error) {
	if atEOF && len(data) == 0 {
		return 0, nil, nil
	}

	// Look for newline or carriage return
	for i := 0; i < len(data); i++ {
		if data[i] == '\n' || data[i] == '\r' {
			return i + 1, data[0:i], nil
		}
	}

	if atEOF {
		return len(data), data, nil
	}

	return 0, nil, nil
}

// parseResultsAndUpdate reads the results file and updates the database
func (b *BulkAnalyzer) parseResultsAndUpdate(outputFile string) error {
	data, err := os.ReadFile(outputFile)
	if err != nil {
		return fmt.Errorf("failed to read results file: %w", err)
	}

	var output BulkOutput
	if err := json.Unmarshal(data, &output); err != nil {
		return fmt.Errorf("failed to parse results JSON: %w", err)
	}

	b.log("info", fmt.Sprintf("[Bulk] Processing %d results", len(output.Results)))

	for _, result := range output.Results {
		if err := b.processResult(result); err != nil {
			b.log("error", fmt.Sprintf("[Bulk] Failed to process %s: %v", result.File, err))
		}
	}

	return nil
}

// processResult processes a single result and updates the database
func (b *BulkAnalyzer) processResult(result BulkResult) error {
	// Find the file in database
	file, err := b.fileRepo.GetByPath(result.File)
	if err != nil {
		return fmt.Errorf("file not found in database: %w", err)
	}
	if file == nil {
		return fmt.Errorf("file not found: %s", result.File)
	}

	if !result.Success {
		// Check if it was rate limited - keep as pending for retry
		if strings.Contains(strings.ToLower(result.Error), "rate limit") {
			b.log("warn", fmt.Sprintf("[Bulk] Rate limited, will retry: %s", result.File))
			// Don't change status - stays pending for next run
			return nil
		}
		// Actual failure (no match, etc.) - mark as error
		errorMsg := result.Error
		if errorMsg == "" {
			errorMsg = "no match found"
		}
		b.fileRepo.SetError(file.ID, errorMsg)
		b.log("info", fmt.Sprintf("[Bulk] No match: %s", result.File))
		return nil
	}

	// Parse the response
	var shazamResp ShazamBulkResponse
	if err := json.Unmarshal(result.Response, &shazamResp); err != nil {
		return fmt.Errorf("failed to parse shazam response: %w", err)
	}

	if shazamResp.Track == nil {
		b.fileRepo.SetError(file.ID, "no track in response")
		return nil
	}

	// Convert to metadata
	meta := b.convertToMetadata(shazamResp.Track)

	// Update file in database
	file.Status = database.StatusRecognized
	file.Title = meta.Title
	file.Artist = meta.Artist
	file.Album = meta.Album
	file.Year = meta.Year
	file.Genre = meta.GetPrimaryGenre()
	file.ISRC = meta.ISRC
	file.RecognitionService = "shazam"
	file.Confidence = 0.95
	file.ShazamID = meta.ShazamID
	file.ArtworkURL = meta.GetBestArtworkURL()

	if err := b.fileRepo.UpdateRecognition(file); err != nil {
		return fmt.Errorf("failed to update file: %w", err)
	}

	b.log("info", fmt.Sprintf("[Bulk] Matched: %s - %s", meta.Artist, meta.Title))
	return nil
}

// convertToMetadata converts a Shazam track to unified metadata
func (b *BulkAnalyzer) convertToMetadata(track *ShazamTrack) *metadata.Unified {
	m := metadata.NewUnified()

	m.Service = "shazam"
	m.Confidence = 0.95

	// Basic info
	m.Title = track.Title
	m.Artist = track.Subtitle // Shazam puts artist in subtitle
	m.ShazamID = track.Key
	m.ISRC = track.ISRC

	// Genre
	m.Genre = track.Genres.Primary

	// Artwork
	m.ArtworkURL = track.Images.Coverart
	m.ArtworkURLHQ = track.Images.CoverartHQ

	// Links
	m.ShazamURL = track.Share.Href

	// Extract additional info from sections
	for _, section := range track.Sections {
		if section.Type == "SONG" {
			for _, meta := range section.Metadata {
				switch meta.Title {
				case "Album":
					m.Album = meta.Text
				case "Released", "Sorti": // French locale
					m.ReleaseDate = meta.Text
					// Try to extract year
					if len(meta.Text) >= 4 {
						if year, err := strconv.Atoi(meta.Text[:4]); err == nil {
							m.Year = year
						}
					}
				case "Label":
					m.Label = meta.Text
				}
			}
		}
	}

	// Extract Apple Music / Spotify links from hub
	for _, provider := range track.Hub.Providers {
		for _, action := range provider.Actions {
			if strings.Contains(action.URI, "apple") {
				m.AppleMusicURL = action.URI
			} else if strings.Contains(action.URI, "spotify") {
				m.SpotifyURL = action.URI
			}
		}
	}

	return m
}
