package recognition

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/packalyst/vibra-go/internal/proxy"
	"github.com/packalyst/vibra-go/pkg/metadata"
)

// Common errors
var (
	ErrNoMatch     = errors.New("no match found")
	ErrRateLimited = errors.New("rate limited (429)")
	ErrTimeout     = errors.New("request timeout")
	ErrDisabled    = errors.New("service disabled")
)

// Service defines the interface for recognition services
type Service interface {
	Recognize(ctx context.Context, filePath string) (*metadata.Unified, error)
	Name() string
}

// Config holds configuration for all recognition services
type Config struct {
	// Service enable/disable
	ShazamEnabled     bool `json:"shazam_enabled"`
	AcoustIDEnabled   bool `json:"acoustid_enabled"`
	ITunesEnabled     bool `json:"itunes_enabled"`
	MusicBrainzEnrich bool `json:"musicbrainz_enrich"`
	FallbackEnabled   bool `json:"fallback_enabled"`

	// Timeouts
	ShazamTimeout   time.Duration `json:"shazam_timeout"`
	AcoustIDTimeout time.Duration `json:"acoustid_timeout"`
	ITunesTimeout   time.Duration `json:"itunes_timeout"`

	// API keys
	AcoustIDAPIKey string `json:"acoustid_api_key"`

	// Service order (e.g., ["shazam", "acoustid", "itunes", "fallback"])
	ServiceOrder []string `json:"service_order"`

	// Confidence
	HighConfidenceThreshold float64 `json:"high_confidence_threshold"`
	StopOnHighConfidence    bool    `json:"stop_on_high_confidence"`
	MinConfidenceDelta      float64 `json:"min_confidence_delta"`
}

// DefaultConfig returns default recognition configuration
func DefaultConfig() Config {
	return Config{
		ShazamEnabled:           true,
		AcoustIDEnabled:         true,
		ITunesEnabled:           true,
		MusicBrainzEnrich:       true,
		FallbackEnabled:         true,
		ShazamTimeout:           30 * time.Second,
		AcoustIDTimeout:         30 * time.Second,
		ITunesTimeout:           30 * time.Second,
		ServiceOrder:            []string{"shazam", "acoustid", "itunes", "fallback"},
		HighConfidenceThreshold: 0.9,
		StopOnHighConfidence:    true,
		MinConfidenceDelta:      0.1,
	}
}

// Orchestrator coordinates recognition across multiple services
type Orchestrator struct {
	config   Config
	proxyMgr *proxy.Manager
	services map[string]Service

	// Event callbacks
	onLog func(level, message string)
}

// NewOrchestrator creates a new recognition orchestrator
func NewOrchestrator(config Config, proxyMgr *proxy.Manager) *Orchestrator {
	o := &Orchestrator{
		config:   config,
		proxyMgr: proxyMgr,
		services: make(map[string]Service),
	}

	// Initialize services
	if config.ShazamEnabled {
		shazam := NewShazamService(proxyMgr, config.ShazamTimeout)
		o.services["shazam"] = shazam
	}
	if config.AcoustIDEnabled && config.AcoustIDAPIKey != "" {
		o.services["acoustid"] = NewAcoustIDService(config.AcoustIDAPIKey, config.AcoustIDTimeout)
	}
	if config.ITunesEnabled {
		o.services["itunes"] = NewITunesService(config.ITunesTimeout)
	}
	if config.FallbackEnabled {
		o.services["fallback"] = NewFallbackService()
	}

	return o
}

// SetLogHandler sets the logging callback
func (o *Orchestrator) SetLogHandler(handler func(level, message string)) {
	o.onLog = handler
	// Pass log handler to services that support it
	if shazam, ok := o.services["shazam"].(*ShazamService); ok {
		shazam.SetLogHandler(handler)
	}
}

func (o *Orchestrator) log(level, message string) {
	if o.onLog != nil {
		o.onLog(level, message)
	}
}

// Recognize attempts to recognize a file using configured services in order
func (o *Orchestrator) Recognize(ctx context.Context, filePath string) (*metadata.Unified, error) {
	result := metadata.NewUnified()
	var lastErr error

	for _, serviceName := range o.config.ServiceOrder {
		service, ok := o.services[serviceName]
		if !ok {
			continue // Service not available
		}

		select {
		case <-ctx.Done():
			return result, ctx.Err()
		default:
		}

		o.log("debug", fmt.Sprintf("Trying %s for %s", serviceName, filePath))

		// Check if rate limited
		if err := o.proxyMgr.WaitIfRateLimited(ctx); err != nil {
			return result, err
		}

		// Try recognition
		match, err := service.Recognize(ctx, filePath)
		if err != nil {
			if errors.Is(err, ErrRateLimited) {
				o.log("warn", fmt.Sprintf("%s: rate limited", serviceName))
				// Handle rate limiting
				if handleErr := o.proxyMgr.OnRateLimit(ctx); handleErr != nil {
					return result, handleErr
				}
				// Retry same service after rate limit handling
				match, err = service.Recognize(ctx, filePath)
			}

			if err != nil {
				if !errors.Is(err, ErrNoMatch) {
					o.log("error", fmt.Sprintf("%s failed: %v", serviceName, err))
					lastErr = err
				} else {
					o.log("debug", fmt.Sprintf("%s: no match", serviceName))
				}
				continue
			}
		}

		if match != nil {
			o.log("info", fmt.Sprintf("%s: matched '%s - %s' (confidence: %.2f)",
				serviceName, match.Artist, match.Title, match.Confidence))

			// Merge into result
			result.Merge(match, o.config.MinConfidenceDelta)

			// Reset proxy retry count on success
			o.proxyMgr.ResetRetryCount()

			// Check if we should stop early
			if o.config.StopOnHighConfidence && result.IsHighConfidence(o.config.HighConfidenceThreshold) {
				o.log("debug", "High confidence reached, stopping early")
				break
			}
		}
	}

	if !result.IsComplete() {
		if lastErr != nil {
			return result, lastErr
		}
		return result, ErrNoMatch
	}

	return result, nil
}

// UpdateConfig updates the orchestrator configuration
func (o *Orchestrator) UpdateConfig(config Config) {
	o.config = config

	// Reinitialize services
	o.services = make(map[string]Service)

	if config.ShazamEnabled {
		o.services["shazam"] = NewShazamService(o.proxyMgr, config.ShazamTimeout)
	}
	if config.AcoustIDEnabled && config.AcoustIDAPIKey != "" {
		o.services["acoustid"] = NewAcoustIDService(config.AcoustIDAPIKey, config.AcoustIDTimeout)
	}
	if config.ITunesEnabled {
		o.services["itunes"] = NewITunesService(config.ITunesTimeout)
	}
	if config.FallbackEnabled {
		o.services["fallback"] = NewFallbackService()
	}
}

// GetEnabledServices returns a list of enabled service names
func (o *Orchestrator) GetEnabledServices() []string {
	var enabled []string
	for _, name := range o.config.ServiceOrder {
		if _, ok := o.services[name]; ok {
			enabled = append(enabled, name)
		}
	}
	return enabled
}
