package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/packalyst/vibra-go/internal/database"
	"github.com/packalyst/vibra-go/internal/proxy"
	"github.com/packalyst/vibra-go/internal/recognition"
)

// SettingsHandler handles settings-related requests
type SettingsHandler struct {
	settingsRepo *database.SettingsRepository
	proxyMgr     *proxy.Manager
	orchestrator *recognition.Orchestrator
}

// NewSettingsHandler creates a new settings handler
func NewSettingsHandler(
	settingsRepo *database.SettingsRepository,
	proxyMgr *proxy.Manager,
	orchestrator *recognition.Orchestrator,
) *SettingsHandler {
	return &SettingsHandler{
		settingsRepo: settingsRepo,
		proxyMgr:     proxyMgr,
		orchestrator: orchestrator,
	}
}

// Settings represents all application settings
type Settings struct {
	// Paths
	WatchFolder  string `json:"watch_folder"`
	OutputFolder string `json:"output_folder"`

	// Proxy
	ProxyEnabled         bool   `json:"proxy_enabled"`
	ProxyHost            string `json:"proxy_host"`
	ProxyPort            int    `json:"proxy_port"`
	ProxyType            string `json:"proxy_type"`
	ProxyUsername        string `json:"proxy_username"`
	ProxyPassword        string `json:"proxy_password"`
	ProxyRotationURL     string `json:"proxy_rotation_url"`
	ProxyRotationTimeout int    `json:"proxy_rotation_timeout"`

	// Services
	ShazamEnabled     bool     `json:"shazam_enabled"`
	ShazamTimeout     int      `json:"shazam_timeout"`
	AcoustIDEnabled   bool     `json:"acoustid_enabled"`
	AcoustIDAPIKey    string   `json:"acoustid_api_key"`
	AcoustIDTimeout   int      `json:"acoustid_timeout"`
	ITunesEnabled     bool     `json:"itunes_enabled"`
	MusicBrainzEnrich bool     `json:"musicbrainz_enrich"`
	FallbackEnabled   bool     `json:"fallback_enabled"`
	ServiceOrder      []string `json:"service_order"`

	// Processing
	Workers               int     `json:"workers"`
	BatchSize             int     `json:"batch_size"`
	DelayBetweenMS        int     `json:"delay_between_ms"`
	DelayBetweenBatches   int     `json:"delay_between_batches"`
	MaxFileSizeMB         int     `json:"max_file_size_mb"`
	StopOnHighConfidence  bool    `json:"stop_on_high_confidence"`
	HighConfidenceThreshold float64 `json:"high_confidence_threshold"`

	// Organization
	OrganizationEnabled    bool   `json:"organization_enabled"`
	OrganizationPattern    string `json:"organization_pattern"`
	MoveFiles              bool   `json:"move_files"`
	DuplicateAction        string `json:"duplicate_action"`
	FilenameFormat         string `json:"filename_format"`
	IncludeTrackNumber     bool   `json:"include_track_number"`
	IncludeYearInAlbum     bool   `json:"include_year_in_album"`

	// Tag Writing
	TagWritingEnabled bool   `json:"tag_writing_enabled"`
	ClearExistingTags bool   `json:"clear_existing_tags"`
	EmbedArtwork      bool   `json:"embed_artwork"`
	ArtworkMaxSize    int    `json:"artwork_max_size"`
	BackupBeforeTag   bool   `json:"backup_before_tagging"`
	BackupFolder      string `json:"backup_folder"`
}

// GetAll returns all settings
func (h *SettingsHandler) GetAll(w http.ResponseWriter, r *http.Request) {
	raw, err := h.settingsRepo.GetAll()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	settings := h.mapToSettings(raw)
	writeJSON(w, settings)
}

// Update updates settings
func (h *SettingsHandler) Update(w http.ResponseWriter, r *http.Request) {
	var settings Settings
	if err := json.NewDecoder(r.Body).Decode(&settings); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Convert to map and save
	raw := h.settingsToMap(settings)
	if err := h.settingsRepo.SetAll(raw); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Update proxy configuration
	h.proxyMgr.UpdateConfig(proxy.Config{
		Enabled:         settings.ProxyEnabled,
		Host:            settings.ProxyHost,
		Port:            settings.ProxyPort,
		Type:            settings.ProxyType,
		Username:        settings.ProxyUsername,
		Password:        settings.ProxyPassword,
		RotationURL:     settings.ProxyRotationURL,
		RotationTimeout: settings.ProxyRotationTimeout,
	})

	// Update recognition configuration
	h.orchestrator.UpdateConfig(recognition.Config{
		ShazamEnabled:           settings.ShazamEnabled,
		AcoustIDEnabled:         settings.AcoustIDEnabled,
		ITunesEnabled:           settings.ITunesEnabled,
		MusicBrainzEnrich:       settings.MusicBrainzEnrich,
		FallbackEnabled:         settings.FallbackEnabled,
		ShazamTimeout:           time.Duration(settings.ShazamTimeout) * time.Second,
		AcoustIDTimeout:         time.Duration(settings.AcoustIDTimeout) * time.Second,
		AcoustIDAPIKey:          settings.AcoustIDAPIKey,
		ServiceOrder:            settings.ServiceOrder,
		HighConfidenceThreshold: settings.HighConfidenceThreshold,
		StopOnHighConfidence:    settings.StopOnHighConfidence,
	})

	writeJSON(w, map[string]string{
		"status": "updated",
	})
}

func (h *SettingsHandler) mapToSettings(raw map[string]string) Settings {
	return Settings{
		WatchFolder:             raw["watch_folder"],
		OutputFolder:            raw["output_folder"],
		ProxyEnabled:            raw["proxy_enabled"] == "true",
		ProxyHost:               raw["proxy_host"],
		ProxyPort:               atoi(raw["proxy_port"], 8080),
		ProxyType:               raw["proxy_type"],
		ProxyUsername:           raw["proxy_username"],
		ProxyPassword:           raw["proxy_password"],
		ProxyRotationURL:        raw["proxy_rotation_url"],
		ProxyRotationTimeout:    atoi(raw["proxy_rotation_timeout"], 60),
		ShazamEnabled:           raw["shazam_enabled"] != "false",
		ShazamTimeout:           atoi(raw["shazam_timeout"], 30),
		AcoustIDEnabled:         raw["acoustid_enabled"] != "false",
		AcoustIDAPIKey:          raw["acoustid_api_key"],
		AcoustIDTimeout:         atoi(raw["acoustid_timeout"], 30),
		ITunesEnabled:           raw["itunes_enabled"] != "false",
		MusicBrainzEnrich:       raw["musicbrainz_enrich"] != "false",
		FallbackEnabled:         raw["fallback_enabled"] != "false",
		ServiceOrder:            strings.Split(raw["service_order"], ","),
		Workers:                 atoi(raw["workers"], 4),
		BatchSize:               atoi(raw["batch_size"], 100),
		DelayBetweenMS:          atoi(raw["delay_between_ms"], 0),
		DelayBetweenBatches:     atoi(raw["delay_between_batches"], 0),
		MaxFileSizeMB:           atoi(raw["max_file_size_mb"], 500),
		StopOnHighConfidence:    raw["stop_on_high_confidence"] != "false",
		HighConfidenceThreshold: atof(raw["high_confidence_threshold"], 0.9),
		OrganizationEnabled:     raw["organization_enabled"] != "false",
		OrganizationPattern:     raw["organization_pattern"],
		MoveFiles:               raw["move_files"] == "true",
		DuplicateAction:         raw["duplicate_action"],
		FilenameFormat:          raw["filename_format"],
		IncludeTrackNumber:      raw["include_track_number"] != "false",
		IncludeYearInAlbum:      raw["include_year_in_album"] == "true",
		TagWritingEnabled:       raw["tag_writing_enabled"] != "false",
		ClearExistingTags:       raw["clear_existing_tags"] == "true",
		EmbedArtwork:            raw["embed_artwork"] != "false",
		ArtworkMaxSize:          atoi(raw["artwork_max_size"], 600),
		BackupBeforeTag:         raw["backup_before_tagging"] == "true",
		BackupFolder:            raw["backup_folder"],
	}
}

func (h *SettingsHandler) settingsToMap(s Settings) map[string]string {
	return map[string]string{
		"watch_folder":              s.WatchFolder,
		"output_folder":             s.OutputFolder,
		"proxy_enabled":             strconv.FormatBool(s.ProxyEnabled),
		"proxy_host":                s.ProxyHost,
		"proxy_port":                strconv.Itoa(s.ProxyPort),
		"proxy_type":                s.ProxyType,
		"proxy_username":            s.ProxyUsername,
		"proxy_password":            s.ProxyPassword,
		"proxy_rotation_url":        s.ProxyRotationURL,
		"proxy_rotation_timeout":    strconv.Itoa(s.ProxyRotationTimeout),
		"shazam_enabled":            strconv.FormatBool(s.ShazamEnabled),
		"shazam_timeout":            strconv.Itoa(s.ShazamTimeout),
		"acoustid_enabled":          strconv.FormatBool(s.AcoustIDEnabled),
		"acoustid_api_key":          s.AcoustIDAPIKey,
		"acoustid_timeout":          strconv.Itoa(s.AcoustIDTimeout),
		"itunes_enabled":            strconv.FormatBool(s.ITunesEnabled),
		"musicbrainz_enrich":        strconv.FormatBool(s.MusicBrainzEnrich),
		"fallback_enabled":          strconv.FormatBool(s.FallbackEnabled),
		"service_order":             strings.Join(s.ServiceOrder, ","),
		"workers":                   strconv.Itoa(s.Workers),
		"batch_size":                strconv.Itoa(s.BatchSize),
		"delay_between_ms":          strconv.Itoa(s.DelayBetweenMS),
		"delay_between_batches":     strconv.Itoa(s.DelayBetweenBatches),
		"max_file_size_mb":          strconv.Itoa(s.MaxFileSizeMB),
		"stop_on_high_confidence":   strconv.FormatBool(s.StopOnHighConfidence),
		"high_confidence_threshold": strconv.FormatFloat(s.HighConfidenceThreshold, 'f', 2, 64),
		"organization_enabled":      strconv.FormatBool(s.OrganizationEnabled),
		"organization_pattern":      s.OrganizationPattern,
		"move_files":                strconv.FormatBool(s.MoveFiles),
		"duplicate_action":          s.DuplicateAction,
		"filename_format":           s.FilenameFormat,
		"include_track_number":      strconv.FormatBool(s.IncludeTrackNumber),
		"include_year_in_album":     strconv.FormatBool(s.IncludeYearInAlbum),
		"tag_writing_enabled":       strconv.FormatBool(s.TagWritingEnabled),
		"clear_existing_tags":       strconv.FormatBool(s.ClearExistingTags),
		"embed_artwork":             strconv.FormatBool(s.EmbedArtwork),
		"artwork_max_size":          strconv.Itoa(s.ArtworkMaxSize),
		"backup_before_tagging":     strconv.FormatBool(s.BackupBeforeTag),
		"backup_folder":             s.BackupFolder,
	}
}

func atoi(s string, def int) int {
	if v, err := strconv.Atoi(s); err == nil {
		return v
	}
	return def
}

func atof(s string, def float64) float64 {
	if v, err := strconv.ParseFloat(s, 64); err == nil {
		return v
	}
	return def
}
