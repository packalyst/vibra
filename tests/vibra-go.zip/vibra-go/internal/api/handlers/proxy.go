package handlers

import (
	"context"
	"net/http"
	"time"

	"github.com/packalyst/vibra-go/internal/proxy"
)

// ProxyHandler handles proxy-related requests
type ProxyHandler struct {
	proxyMgr *proxy.Manager
}

// NewProxyHandler creates a new proxy handler
func NewProxyHandler(proxyMgr *proxy.Manager) *ProxyHandler {
	return &ProxyHandler{proxyMgr: proxyMgr}
}

// TestResponse represents the proxy test response
type TestResponse struct {
	Success bool   `json:"success"`
	IP      string `json:"ip"`
	Message string `json:"message,omitempty"`
}

// Test tests the proxy connection
func (h *ProxyHandler) Test(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()

	ip, err := h.proxyMgr.TestConnection(ctx)
	if err != nil {
		writeJSON(w, TestResponse{
			Success: false,
			Message: err.Error(),
		})
		return
	}

	writeJSON(w, TestResponse{
		Success: true,
		IP:      ip,
		Message: "Proxy connection successful",
	})
}

// GetIP returns the current IP address
func (h *ProxyHandler) GetIP(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()

	ip, err := h.proxyMgr.TestConnection(ctx)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	writeJSON(w, map[string]string{
		"ip": ip,
	})
}
