package handlers

import (
	"net/http"

	"github.com/packalyst/vibra-go/internal/database"
)

// StatsHandler handles stats-related requests
type StatsHandler struct {
	fileRepo *database.FileRepository
}

// NewStatsHandler creates a new stats handler
func NewStatsHandler(fileRepo *database.FileRepository) *StatsHandler {
	return &StatsHandler{fileRepo: fileRepo}
}

// Get returns library statistics
func (h *StatsHandler) Get(w http.ResponseWriter, r *http.Request) {
	stats, err := h.fileRepo.GetStats()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	writeJSON(w, stats)
}
