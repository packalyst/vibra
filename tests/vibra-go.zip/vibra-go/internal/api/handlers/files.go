package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"

	"github.com/packalyst/vibra-go/internal/api/websocket"
	"github.com/packalyst/vibra-go/internal/database"
	"github.com/packalyst/vibra-go/internal/recognition"
	"github.com/packalyst/vibra-go/internal/scanner"
	"github.com/packalyst/vibra-go/internal/worker"
)

// FilesHandler handles file-related requests
type FilesHandler struct {
	fileRepo     *database.FileRepository
	scanner      *scanner.Scanner
	workerPool   *worker.Pool
	bulkAnalyzer *recognition.BulkAnalyzer
	wsHub        *websocket.Hub
}

// NewFilesHandler creates a new files handler
func NewFilesHandler(
	fileRepo *database.FileRepository,
	scanner *scanner.Scanner,
	workerPool *worker.Pool,
	bulkAnalyzer *recognition.BulkAnalyzer,
	wsHub *websocket.Hub,
) *FilesHandler {
	return &FilesHandler{
		fileRepo:     fileRepo,
		scanner:      scanner,
		workerPool:   workerPool,
		bulkAnalyzer: bulkAnalyzer,
		wsHub:        wsHub,
	}
}

// ListResponse represents the paginated list response
type ListResponse struct {
	Files      []*database.File `json:"files"`
	Total      int              `json:"total"`
	Page       int              `json:"page"`
	PerPage    int              `json:"per_page"`
	TotalPages int              `json:"total_pages"`
}

// List returns a paginated list of files
func (h *FilesHandler) List(w http.ResponseWriter, r *http.Request) {
	// Parse query parameters
	status := r.URL.Query().Get("status")
	pageStr := r.URL.Query().Get("page")
	perPageStr := r.URL.Query().Get("per_page")

	page := 1
	perPage := 50

	if p, err := strconv.Atoi(pageStr); err == nil && p > 0 {
		page = p
	}
	if pp, err := strconv.Atoi(perPageStr); err == nil && pp > 0 && pp <= 100 {
		perPage = pp
	}

	offset := (page - 1) * perPage

	// Get files based on status
	var files []*database.File
	var err error

	if status != "" {
		files, err = h.fileRepo.ListByStatus(database.FileStatus(status), perPage, offset)
	} else {
		// TODO: Add ListAll method to fileRepo
		files, err = h.fileRepo.ListByStatus(database.StatusPending, perPage, offset)
	}

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Get total count
	stats, _ := h.fileRepo.GetStats()
	total := stats.Total

	response := ListResponse{
		Files:      files,
		Total:      total,
		Page:       page,
		PerPage:    perPage,
		TotalPages: (total + perPage - 1) / perPage,
	}

	writeJSON(w, response)
}

// Get returns a single file by ID
func (h *FilesHandler) Get(w http.ResponseWriter, r *http.Request) {
	idStr := chi.URLParam(r, "id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	file, err := h.fileRepo.GetByID(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	if file == nil {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}

	writeJSON(w, file)
}

// ScanRequest represents a scan request
type ScanRequest struct {
	Directory string `json:"directory"`
	Path      string `json:"path"`
}

// Scan starts a directory scan
func (h *FilesHandler) Scan(w http.ResponseWriter, r *http.Request) {
	var req ScanRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Accept both "directory" and "path"
	dir := req.Directory
	if dir == "" {
		dir = req.Path
	}

	if dir == "" {
		http.Error(w, "Directory or path is required", http.StatusBadRequest)
		return
	}
	req.Directory = dir

	// Start scan in background with independent context
	go func() {
		h.scanner.Scan(context.Background(), req.Directory)
	}()

	writeJSON(w, map[string]string{
		"status":  "started",
		"message": "Scan started, check WebSocket for progress",
	})
}

// AnalyzeRequest represents an analyze request
type AnalyzeRequest struct {
	Directory string `json:"directory"`
	Threads   int    `json:"threads"`
	Delay     int    `json:"delay"`
}

// Analyze starts analyzing pending files using bulk mode
func (h *FilesHandler) Analyze(w http.ResponseWriter, r *http.Request) {
	var req AnalyzeRequest
	json.NewDecoder(r.Body).Decode(&req)

	// Check if already running
	if h.bulkAnalyzer.IsRunning() {
		http.Error(w, "Analysis already in progress", http.StatusConflict)
		return
	}

	// Default directory
	if req.Directory == "" {
		req.Directory = "/music"
	}

	// Log start
	fmt.Printf("[analyze] Starting bulk analysis on %s\n", req.Directory)

	// Start bulk analysis in background
	go func() {
		if err := h.bulkAnalyzer.AnalyzeDirectory(context.Background(), req.Directory); err != nil {
			fmt.Printf("[analyze] Bulk analysis error: %v\n", err)
		}
	}()

	writeJSON(w, map[string]string{
		"status":  "started",
		"message": "Bulk analysis started, check WebSocket for progress",
	})
}

// Organize starts organizing recognized files
func (h *FilesHandler) Organize(w http.ResponseWriter, r *http.Request) {
	// TODO: Implement file organization
	writeJSON(w, map[string]string{
		"status":  "started",
		"message": "Organization started",
	})
}

// Delete deletes a file record
func (h *FilesHandler) Delete(w http.ResponseWriter, r *http.Request) {
	idStr := chi.URLParam(r, "id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	// TODO: Add Delete method to fileRepo
	_ = id

	writeJSON(w, map[string]string{
		"status":  "deleted",
		"message": "File deleted",
	})
}

func writeJSON(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}
