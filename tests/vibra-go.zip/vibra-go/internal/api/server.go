package api

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"

	"github.com/packalyst/vibra-go/internal/api/handlers"
	"github.com/packalyst/vibra-go/internal/api/websocket"
	"github.com/packalyst/vibra-go/internal/database"
	"github.com/packalyst/vibra-go/internal/proxy"
	"github.com/packalyst/vibra-go/internal/recognition"
	"github.com/packalyst/vibra-go/internal/scanner"
	"github.com/packalyst/vibra-go/internal/worker"
)

// Server is the HTTP API server
type Server struct {
	router   *chi.Mux
	wsHub    *websocket.Hub
	port     int
	staticDir string

	// Services
	fileRepo     *database.FileRepository
	settingsRepo *database.SettingsRepository
	proxyMgr     *proxy.Manager
	orchestrator *recognition.Orchestrator
	scanner      *scanner.Scanner
	workerPool   *worker.Pool
	bulkAnalyzer *recognition.BulkAnalyzer

	// HTTP server
	httpServer *http.Server
}

// NewServer creates a new API server
func NewServer(
	port int,
	staticDir string,
	fileRepo *database.FileRepository,
	settingsRepo *database.SettingsRepository,
	proxyMgr *proxy.Manager,
	orchestrator *recognition.Orchestrator,
) *Server {
	s := &Server{
		router:       chi.NewRouter(),
		wsHub:        websocket.NewHub(),
		port:         port,
		staticDir:    staticDir,
		fileRepo:     fileRepo,
		settingsRepo: settingsRepo,
		proxyMgr:     proxyMgr,
		orchestrator: orchestrator,
	}

	// Create scanner
	s.scanner = scanner.NewScanner(fileRepo)
	s.scanner.SetProgressHandler(func(p scanner.Progress) {
		s.wsHub.Broadcast("scan_progress", p)
	})
	s.scanner.SetLogHandler(func(level, msg string) {
		fmt.Printf("[scanner][%s] %s\n", level, msg)
		s.wsHub.Broadcast("log", map[string]string{"level": level, "message": msg})
	})

	// Create worker pool (kept for fallback services)
	s.workerPool = worker.NewPool(4, fileRepo, orchestrator, proxyMgr)
	s.workerPool.SetProgressHandler(func(p worker.Progress) {
		s.wsHub.Broadcast("analyze_progress", p)
	})
	s.workerPool.SetLogHandler(func(level, msg string) {
		fmt.Printf("[worker][%s] %s\n", level, msg)
		s.wsHub.Broadcast("log", map[string]string{"level": level, "message": msg})
	})

	// Create bulk analyzer for vibra-cli bulk mode
	s.bulkAnalyzer = recognition.NewBulkAnalyzer("/data", 4, 2, fileRepo)
	s.bulkAnalyzer.SetProgressHandler(func(p recognition.BulkProgress) {
		s.wsHub.Broadcast("analyze_progress", map[string]interface{}{
			"total":     p.Total,
			"completed": p.Processed,
			"succeeded": p.OK,
			"failed":    p.Failed,
			"current":   p.Current,
			"done":      p.Done,
			"percent":   p.Percent,
		})
	})
	s.bulkAnalyzer.SetLogHandler(func(level, msg string) {
		fmt.Printf("[bulk][%s] %s\n", level, msg)
		s.wsHub.Broadcast("log", map[string]string{"level": level, "message": msg})
	})

	// Set orchestrator log handler for service-level logging
	orchestrator.SetLogHandler(func(level, msg string) {
		fmt.Printf("[%s] %s\n", level, msg) // Also log to stdout
		s.wsHub.Broadcast("log", map[string]string{"level": level, "message": msg})
	})

	s.setupMiddleware()
	s.setupRoutes()

	return s
}

func (s *Server) setupMiddleware() {
	s.router.Use(middleware.Logger)
	s.router.Use(middleware.Recoverer)
	s.router.Use(middleware.RequestID)
	s.router.Use(middleware.RealIP)
	s.router.Use(middleware.Timeout(60 * time.Second))

	// CORS
	s.router.Use(cors.Handler(cors.Options{
		AllowedOrigins:   []string{"*"},
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type"},
		ExposedHeaders:   []string{"Link"},
		AllowCredentials: true,
		MaxAge:           300,
	}))
}

func (s *Server) setupRoutes() {
	// Create handlers
	filesHandler := handlers.NewFilesHandler(s.fileRepo, s.scanner, s.workerPool, s.bulkAnalyzer, s.wsHub)
	settingsHandler := handlers.NewSettingsHandler(s.settingsRepo, s.proxyMgr, s.orchestrator)
	statsHandler := handlers.NewStatsHandler(s.fileRepo)
	proxyHandler := handlers.NewProxyHandler(s.proxyMgr)

	// API routes
	s.router.Route("/api", func(r chi.Router) {
		// Files
		r.Get("/files", filesHandler.List)
		r.Get("/files/{id}", filesHandler.Get)
		r.Post("/files/scan", filesHandler.Scan)
		r.Post("/files/analyze", filesHandler.Analyze)
		r.Post("/files/organize", filesHandler.Organize)
		r.Delete("/files/{id}", filesHandler.Delete)

		// Settings
		r.Get("/settings", settingsHandler.GetAll)
		r.Put("/settings", settingsHandler.Update)

		// Stats
		r.Get("/stats", statsHandler.Get)

		// Proxy
		r.Post("/proxy/test", proxyHandler.Test)
		r.Get("/proxy/ip", proxyHandler.GetIP)

		// WebSocket
		r.Get("/ws", s.handleWebSocket)
	})

	// Static files (SPA)
	if s.staticDir != "" {
		fileServer := http.FileServer(http.Dir(s.staticDir))
		s.router.Handle("/*", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Try to serve the file, fallback to index.html for SPA routing
			if _, err := http.Dir(s.staticDir).Open(r.URL.Path); err != nil {
				// File doesn't exist, serve index.html (SPA)
				http.ServeFile(w, r, s.staticDir+"/index.html")
				return
			}
			fileServer.ServeHTTP(w, r)
		}))
	}
}

func (s *Server) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	s.wsHub.HandleConnection(w, r)
}

// Start starts the HTTP server
func (s *Server) Start() error {
	// Start WebSocket hub
	go s.wsHub.Run()

	s.httpServer = &http.Server{
		Addr:         fmt.Sprintf("0.0.0.0:%d", s.port),
		Handler:      s.router,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	fmt.Printf("Starting server on http://0.0.0.0:%d\n", s.port)
	return s.httpServer.ListenAndServe()
}

// Shutdown gracefully shuts down the server
func (s *Server) Shutdown(ctx context.Context) error {
	return s.httpServer.Shutdown(ctx)
}

// GetWSHub returns the WebSocket hub
func (s *Server) GetWSHub() *websocket.Hub {
	return s.wsHub
}
