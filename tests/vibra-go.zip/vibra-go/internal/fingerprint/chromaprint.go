package fingerprint

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os/exec"
	"strconv"
	"strings"
)

var (
	ErrFpcalcNotFound = errors.New("fpcalc not found - install chromaprint-tools")
	ErrFpcalcFailed   = errors.New("fpcalc failed to generate fingerprint")
)

// ChromaprintResult holds the result from fpcalc
type ChromaprintResult struct {
	Fingerprint string  `json:"fingerprint"`
	Duration    float64 `json:"duration"`
}

// fpcalcPath is the path to the fpcalc binary
var fpcalcPath = "fpcalc"

// SetFpcalcPath sets a custom path to the fpcalc binary
func SetFpcalcPath(path string) {
	fpcalcPath = path
}

// CheckFpcalc checks if fpcalc is available
func CheckFpcalc() error {
	_, err := exec.LookPath(fpcalcPath)
	if err != nil {
		return ErrFpcalcNotFound
	}
	return nil
}

// GetChromaprint generates an AcoustID fingerprint using fpcalc
func GetChromaprint(filePath string) (*ChromaprintResult, error) {
	// Run fpcalc with JSON output
	cmd := exec.Command(fpcalcPath, "-json", filePath)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("%w: %s", ErrFpcalcFailed, stderr.String())
	}

	// Parse JSON output
	var result ChromaprintResult
	if err := json.Unmarshal(stdout.Bytes(), &result); err != nil {
		// Fallback to parsing text output if JSON fails
		return parseTextOutput(stdout.String())
	}

	if result.Fingerprint == "" {
		return nil, ErrFpcalcFailed
	}

	return &result, nil
}

// GetChromaprintWithDuration generates fingerprint with custom duration limit
func GetChromaprintWithDuration(filePath string, maxDuration int) (*ChromaprintResult, error) {
	cmd := exec.Command(fpcalcPath, "-json", "-length", strconv.Itoa(maxDuration), filePath)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("%w: %s", ErrFpcalcFailed, stderr.String())
	}

	var result ChromaprintResult
	if err := json.Unmarshal(stdout.Bytes(), &result); err != nil {
		return parseTextOutput(stdout.String())
	}

	if result.Fingerprint == "" {
		return nil, ErrFpcalcFailed
	}

	return &result, nil
}

// parseTextOutput parses the older text format from fpcalc
// Format:
//
//	DURATION=123.45
//	FINGERPRINT=AQADtNI...
func parseTextOutput(output string) (*ChromaprintResult, error) {
	result := &ChromaprintResult{}
	lines := strings.Split(output, "\n")

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "DURATION=") {
			dur, err := strconv.ParseFloat(strings.TrimPrefix(line, "DURATION="), 64)
			if err == nil {
				result.Duration = dur
			}
		} else if strings.HasPrefix(line, "FINGERPRINT=") {
			result.Fingerprint = strings.TrimPrefix(line, "FINGERPRINT=")
		}
	}

	if result.Fingerprint == "" {
		return nil, ErrFpcalcFailed
	}

	return result, nil
}

// GetRawChromaprint returns the raw fingerprint data (for comparison)
func GetRawChromaprint(filePath string) (*ChromaprintResult, error) {
	cmd := exec.Command(fpcalcPath, "-json", "-raw", filePath)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("%w: %s", ErrFpcalcFailed, stderr.String())
	}

	var result ChromaprintResult
	if err := json.Unmarshal(stdout.Bytes(), &result); err != nil {
		return nil, fmt.Errorf("failed to parse fpcalc output: %w", err)
	}

	return &result, nil
}
