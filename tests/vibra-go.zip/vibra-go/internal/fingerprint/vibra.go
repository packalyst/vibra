package fingerprint

/*
#cgo CFLAGS: -I${SRCDIR}/../../deps/vibra/include
#cgo LDFLAGS: -L${SRCDIR}/../../deps/vibra/build -lvibra -lfftw3 -lstdc++ -lm

#include <stdlib.h>

// We need a C wrapper because the header uses C++ types (std::string)
// The extern "C" functions provide C-compatible interface

typedef struct Fingerprint Fingerprint;

// Declare the C functions from vibra
extern Fingerprint *vibra_get_fingerprint_from_music_file(const char *music_file_path);
extern Fingerprint *vibra_get_fingerprint_from_offset(const char *music_file_path, unsigned int offset_seconds);
extern Fingerprint *vibra_get_fingerprint_from_signed_pcm(const char *raw_pcm, int pcm_data_size,
                                                          int sample_rate, int sample_width,
                                                          int channel_count);
extern const char *vibra_get_uri_from_fingerprint(Fingerprint *fingerprint);
extern unsigned int vibra_get_sample_ms_from_fingerprint(Fingerprint *fingerprint);
extern void vibra_free_fingerprint(Fingerprint *fingerprint);
extern double vibra_get_duration(const char *music_file_path);
*/
import "C"
import (
	"errors"
	"unsafe"
)

var (
	ErrFingerprintFailed = errors.New("failed to generate fingerprint")
	ErrNilFingerprint    = errors.New("nil fingerprint")
)

// Fingerprint represents an audio fingerprint for Shazam recognition
type Fingerprint struct {
	URI      string // Base64-encoded fingerprint data for Shazam API
	SampleMS uint32 // Duration of the sample in milliseconds
	OffsetMS uint32 // Offset where fingerprinting started
}

// GetFingerprintFromFile generates a fingerprint from an audio file
// The file format is auto-detected (requires FFmpeg for non-WAV formats)
func GetFingerprintFromFile(filePath string) (result *Fingerprint, err error) {
	// Recover from any panic in CGO calls
	defer func() {
		if r := recover(); r != nil {
			err = errors.New("vibra library crashed - possible unsupported audio format")
			result = nil
		}
	}()

	cPath := C.CString(filePath)
	defer C.free(unsafe.Pointer(cPath))

	fp := C.vibra_get_fingerprint_from_music_file(cPath)
	if fp == nil {
		return nil, ErrFingerprintFailed
	}
	defer C.vibra_free_fingerprint(fp)

	return extractFingerprint(fp)
}

// GetFingerprintFromOffset generates a fingerprint starting at a specific offset
func GetFingerprintFromOffset(filePath string, offsetSeconds uint) (*Fingerprint, error) {
	cPath := C.CString(filePath)
	defer C.free(unsafe.Pointer(cPath))

	fp := C.vibra_get_fingerprint_from_offset(cPath, C.uint(offsetSeconds))
	if fp == nil {
		return nil, ErrFingerprintFailed
	}
	defer C.vibra_free_fingerprint(fp)

	return extractFingerprint(fp)
}

// GetFingerprintFromPCM generates a fingerprint from raw signed PCM data
func GetFingerprintFromPCM(pcmData []byte, sampleRate, sampleWidth, channels int) (*Fingerprint, error) {
	if len(pcmData) == 0 {
		return nil, errors.New("empty PCM data")
	}

	fp := C.vibra_get_fingerprint_from_signed_pcm(
		(*C.char)(unsafe.Pointer(&pcmData[0])),
		C.int(len(pcmData)),
		C.int(sampleRate),
		C.int(sampleWidth),
		C.int(channels),
	)
	if fp == nil {
		return nil, ErrFingerprintFailed
	}
	defer C.vibra_free_fingerprint(fp)

	return extractFingerprint(fp)
}

// GetDuration returns the duration of an audio file in seconds
func GetDuration(filePath string) float64 {
	cPath := C.CString(filePath)
	defer C.free(unsafe.Pointer(cPath))

	return float64(C.vibra_get_duration(cPath))
}

// extractFingerprint extracts data from a C Fingerprint pointer
func extractFingerprint(fp *C.Fingerprint) (*Fingerprint, error) {
	if fp == nil {
		return nil, ErrNilFingerprint
	}

	uri := C.vibra_get_uri_from_fingerprint(fp)
	if uri == nil {
		return nil, errors.New("failed to get URI from fingerprint")
	}

	return &Fingerprint{
		URI:      C.GoString(uri),
		SampleMS: uint32(C.vibra_get_sample_ms_from_fingerprint(fp)),
	}, nil
}
