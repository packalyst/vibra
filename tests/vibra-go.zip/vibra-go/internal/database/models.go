package database

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"time"
)

// FileStatus represents the processing status of a file
type FileStatus string

const (
	StatusPending    FileStatus = "pending"
	StatusAnalyzing  FileStatus = "analyzing"
	StatusRecognized FileStatus = "recognized"
	StatusOrganized  FileStatus = "organized"
	StatusError      FileStatus = "error"
)

// File represents a music file in the database
type File struct {
	ID                 int64      `json:"id"`
	Path               string     `json:"path"`
	Hash               string     `json:"hash,omitempty"`
	Status             FileStatus `json:"status"`
	Source             string     `json:"source"`

	// Metadata
	Title       string  `json:"title,omitempty"`
	Artist      string  `json:"artist,omitempty"`
	Album       string  `json:"album,omitempty"`
	Year        int     `json:"year,omitempty"`
	Genre       string  `json:"genre,omitempty"`
	TrackNumber int     `json:"track_number,omitempty"`
	DiscNumber  int     `json:"disc_number,omitempty"`
	Duration    float64 `json:"duration,omitempty"`
	ISRC        string  `json:"isrc,omitempty"`

	// Recognition info
	RecognitionService string  `json:"recognition_service,omitempty"`
	Confidence         float64 `json:"confidence,omitempty"`
	ShazamID           string  `json:"shazam_id,omitempty"`
	MusicBrainzID      string  `json:"musicbrainz_id,omitempty"`
	ITunesID           string  `json:"itunes_id,omitempty"`

	// Artwork
	ArtworkURL    string `json:"artwork_url,omitempty"`
	ArtworkCached bool   `json:"artwork_cached"`

	// Media info
	Codec        string `json:"codec,omitempty"`
	Bitrate      int    `json:"bitrate,omitempty"`
	SampleRate   int    `json:"sample_rate,omitempty"`
	Channels     int    `json:"channels,omitempty"`
	FileSize     int64  `json:"file_size,omitempty"`
	QualityScore int    `json:"quality_score,omitempty"`

	// Error tracking
	ErrorMessage string `json:"error_message,omitempty"`
	RetryCount   int    `json:"retry_count"`

	// Timestamps
	CreatedAt    time.Time  `json:"created_at"`
	UpdatedAt    time.Time  `json:"updated_at"`
	RecognizedAt *time.Time `json:"recognized_at,omitempty"`
	OrganizedAt  *time.Time `json:"organized_at,omitempty"`
}

// FileRepository provides database operations for files
type FileRepository struct{}

// NewFileRepository creates a new FileRepository
func NewFileRepository() *FileRepository {
	return &FileRepository{}
}

// Create inserts a new file into the database
func (r *FileRepository) Create(f *File) error {
	result, err := db.Exec(`
		INSERT INTO files (path, hash, status, source, title, artist, album, year, genre,
			track_number, disc_number, duration, isrc, file_size)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, f.Path, f.Hash, f.Status, f.Source, f.Title, f.Artist, f.Album, f.Year, f.Genre,
		f.TrackNumber, f.DiscNumber, f.Duration, f.ISRC, f.FileSize)
	if err != nil {
		return err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return err
	}
	f.ID = id
	return nil
}

// GetByID retrieves a file by ID
func (r *FileRepository) GetByID(id int64) (*File, error) {
	f := &File{}
	var recognizedAt, organizedAt sql.NullTime
	err := db.QueryRow(`
		SELECT id, path, hash, status, source, title, artist, album, year, genre,
			track_number, disc_number, duration, isrc, recognition_service, confidence,
			shazam_id, musicbrainz_id, itunes_id, artwork_url, artwork_cached,
			codec, bitrate, sample_rate, channels, file_size, quality_score,
			error_message, retry_count, created_at, updated_at, recognized_at, organized_at
		FROM files WHERE id = ?
	`, id).Scan(
		&f.ID, &f.Path, &f.Hash, &f.Status, &f.Source, &f.Title, &f.Artist, &f.Album, &f.Year, &f.Genre,
		&f.TrackNumber, &f.DiscNumber, &f.Duration, &f.ISRC, &f.RecognitionService, &f.Confidence,
		&f.ShazamID, &f.MusicBrainzID, &f.ITunesID, &f.ArtworkURL, &f.ArtworkCached,
		&f.Codec, &f.Bitrate, &f.SampleRate, &f.Channels, &f.FileSize, &f.QualityScore,
		&f.ErrorMessage, &f.RetryCount, &f.CreatedAt, &f.UpdatedAt, &recognizedAt, &organizedAt,
	)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if recognizedAt.Valid {
		f.RecognizedAt = &recognizedAt.Time
	}
	if organizedAt.Valid {
		f.OrganizedAt = &organizedAt.Time
	}
	return f, nil
}

// GetByPath retrieves a file by path
func (r *FileRepository) GetByPath(path string) (*File, error) {
	f := &File{}
	err := db.QueryRow("SELECT id, path, hash, status FROM files WHERE path = ?", path).
		Scan(&f.ID, &f.Path, &f.Hash, &f.Status)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return f, nil
}

// GetByHash retrieves a file by hash
func (r *FileRepository) GetByHash(hash string) (*File, error) {
	f := &File{}
	err := db.QueryRow("SELECT id, path, hash, status FROM files WHERE hash = ?", hash).
		Scan(&f.ID, &f.Path, &f.Hash, &f.Status)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return f, nil
}

// ListByStatus retrieves files by status with pagination
func (r *FileRepository) ListByStatus(status FileStatus, limit, offset int) ([]*File, error) {
	rows, err := db.Query(`
		SELECT id, path, COALESCE(hash, ''), status, COALESCE(source, ''),
			COALESCE(title, ''), COALESCE(artist, ''), COALESCE(album, ''), COALESCE(year, 0), COALESCE(genre, ''),
			COALESCE(recognition_service, ''), COALESCE(confidence, 0), created_at, updated_at
		FROM files WHERE status = ?
		ORDER BY created_at DESC
		LIMIT ? OFFSET ?
	`, status, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var files []*File
	for rows.Next() {
		f := &File{}
		if err := rows.Scan(
			&f.ID, &f.Path, &f.Hash, &f.Status, &f.Source, &f.Title, &f.Artist, &f.Album, &f.Year, &f.Genre,
			&f.RecognitionService, &f.Confidence, &f.CreatedAt, &f.UpdatedAt,
		); err != nil {
			return nil, err
		}
		files = append(files, f)
	}
	return files, rows.Err()
}

// UpdateStatus updates a file's status
func (r *FileRepository) UpdateStatus(id int64, status FileStatus) error {
	_, err := db.Exec("UPDATE files SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", status, id)
	return err
}

// UpdateRecognition updates a file's recognition data
func (r *FileRepository) UpdateRecognition(f *File) error {
	_, err := db.Exec(`
		UPDATE files SET
			status = ?, title = ?, artist = ?, album = ?, year = ?, genre = ?,
			track_number = ?, disc_number = ?, duration = ?, isrc = ?,
			recognition_service = ?, confidence = ?, shazam_id = ?, musicbrainz_id = ?, itunes_id = ?,
			artwork_url = ?, updated_at = CURRENT_TIMESTAMP, recognized_at = CURRENT_TIMESTAMP
		WHERE id = ?
	`, f.Status, f.Title, f.Artist, f.Album, f.Year, f.Genre,
		f.TrackNumber, f.DiscNumber, f.Duration, f.ISRC,
		f.RecognitionService, f.Confidence, f.ShazamID, f.MusicBrainzID, f.ITunesID,
		f.ArtworkURL, f.ID)
	return err
}

// SetError sets an error on a file
func (r *FileRepository) SetError(id int64, errMsg string) error {
	_, err := db.Exec(`
		UPDATE files SET status = ?, error_message = ?, retry_count = retry_count + 1,
			updated_at = CURRENT_TIMESTAMP WHERE id = ?
	`, StatusError, errMsg, id)
	return err
}

// CountByStatus returns the count of files by status
func (r *FileRepository) CountByStatus() (map[FileStatus]int, error) {
	rows, err := db.Query("SELECT status, COUNT(*) FROM files GROUP BY status")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	counts := make(map[FileStatus]int)
	for rows.Next() {
		var status FileStatus
		var count int
		if err := rows.Scan(&status, &count); err != nil {
			return nil, err
		}
		counts[status] = count
	}
	return counts, rows.Err()
}

// Stats represents library statistics
type Stats struct {
	Total      int `json:"total"`
	Pending    int `json:"pending"`
	Analyzing  int `json:"analyzing"`
	Recognized int `json:"recognized"`
	Organized  int `json:"organized"`
	Errors     int `json:"errors"`
}

// GetStats returns library statistics
func (r *FileRepository) GetStats() (*Stats, error) {
	counts, err := r.CountByStatus()
	if err != nil {
		return nil, err
	}

	stats := &Stats{
		Pending:    counts[StatusPending],
		Analyzing:  counts[StatusAnalyzing],
		Recognized: counts[StatusRecognized],
		Organized:  counts[StatusOrganized],
		Errors:     counts[StatusError],
	}
	stats.Total = stats.Pending + stats.Analyzing + stats.Recognized + stats.Organized + stats.Errors
	return stats, nil
}

// SettingsRepository provides database operations for settings
type SettingsRepository struct{}

// NewSettingsRepository creates a new SettingsRepository
func NewSettingsRepository() *SettingsRepository {
	return &SettingsRepository{}
}

// Get retrieves a setting by key
func (r *SettingsRepository) Get(key string) (string, error) {
	var value string
	err := db.QueryRow("SELECT value FROM settings WHERE key = ?", key).Scan(&value)
	if err == sql.ErrNoRows {
		return "", nil
	}
	return value, err
}

// Set stores a setting
func (r *SettingsRepository) Set(key, value string) error {
	_, err := db.Exec(`
		INSERT INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)
		ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
	`, key, value)
	return err
}

// GetAll retrieves all settings as a map
func (r *SettingsRepository) GetAll() (map[string]string, error) {
	rows, err := db.Query("SELECT key, value FROM settings")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	settings := make(map[string]string)
	for rows.Next() {
		var key, value string
		if err := rows.Scan(&key, &value); err != nil {
			return nil, err
		}
		settings[key] = value
	}
	return settings, rows.Err()
}

// SetAll updates multiple settings at once
func (r *SettingsRepository) SetAll(settings map[string]string) error {
	return Transaction(func(tx *sql.Tx) error {
		stmt, err := tx.Prepare(`
			INSERT INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)
			ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
		`)
		if err != nil {
			return err
		}
		defer stmt.Close()

		for key, value := range settings {
			if _, err := stmt.Exec(key, value); err != nil {
				return fmt.Errorf("failed to set %s: %w", key, err)
			}
		}
		return nil
	})
}

// GetJSON retrieves a setting and unmarshals it as JSON
func (r *SettingsRepository) GetJSON(key string, v interface{}) error {
	value, err := r.Get(key)
	if err != nil {
		return err
	}
	if value == "" {
		return nil
	}
	return json.Unmarshal([]byte(value), v)
}

// SetJSON stores a value as JSON
func (r *SettingsRepository) SetJSON(key string, v interface{}) error {
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return r.Set(key, string(data))
}
