package database

import (
	"fmt"
)

// Migration represents a database migration
type Migration struct {
	Version int
	Name    string
	SQL     string
}

// migrations is the list of all database migrations in order
var migrations = []Migration{
	{
		Version: 1,
		Name:    "create_files_table",
		SQL: `
		CREATE TABLE IF NOT EXISTS files (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			path TEXT UNIQUE NOT NULL,
			hash TEXT,
			status TEXT DEFAULT 'pending',
			source TEXT DEFAULT 'local',

			-- Metadata
			title TEXT,
			artist TEXT,
			album TEXT,
			year INTEGER,
			genre TEXT,
			track_number INTEGER,
			disc_number INTEGER,
			duration REAL,
			isrc TEXT,

			-- Recognition info
			recognition_service TEXT,
			confidence REAL,
			shazam_id TEXT,
			musicbrainz_id TEXT,
			itunes_id TEXT,

			-- Artwork
			artwork_url TEXT,
			artwork_cached INTEGER DEFAULT 0,

			-- Media info
			codec TEXT,
			bitrate INTEGER,
			sample_rate INTEGER,
			channels INTEGER,
			file_size INTEGER,
			quality_score INTEGER,

			-- Error tracking
			error_message TEXT,
			retry_count INTEGER DEFAULT 0,

			-- Timestamps
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			recognized_at DATETIME,
			organized_at DATETIME
		);

		CREATE INDEX IF NOT EXISTS idx_files_status ON files(status);
		CREATE INDEX IF NOT EXISTS idx_files_hash ON files(hash);
		CREATE INDEX IF NOT EXISTS idx_files_artist ON files(artist);
		CREATE INDEX IF NOT EXISTS idx_files_album ON files(album);
		`,
	},
	{
		Version: 2,
		Name:    "create_settings_table",
		SQL: `
		CREATE TABLE IF NOT EXISTS settings (
			key TEXT PRIMARY KEY,
			value TEXT,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
		);

		-- Insert default settings
		INSERT OR IGNORE INTO settings (key, value) VALUES
			('watch_folder', ''),
			('output_folder', ''),
			('proxy_enabled', 'false'),
			('proxy_host', ''),
			('proxy_port', '8080'),
			('proxy_type', 'http'),
			('proxy_username', ''),
			('proxy_password', ''),
			('proxy_rotation_url', ''),
			('proxy_rotation_timeout', '60'),
			('shazam_enabled', 'true'),
			('shazam_timeout', '30'),
			('acoustid_enabled', 'true'),
			('acoustid_api_key', ''),
			('acoustid_timeout', '30'),
			('itunes_enabled', 'true'),
			('musicbrainz_enrich', 'true'),
			('fallback_enabled', 'true'),
			('service_order', 'shazam,acoustid,itunes,fallback'),
			('workers', '4'),
			('batch_size', '100'),
			('delay_between_ms', '0'),
			('delay_between_batches', '0'),
			('max_file_size_mb', '500'),
			('stop_on_high_confidence', 'true'),
			('high_confidence_threshold', '0.9'),
			('organization_enabled', 'true'),
			('organization_pattern', 'artist_album'),
			('move_files', 'false'),
			('duplicate_action', 'skip'),
			('filename_format', 'artist_title'),
			('include_track_number', 'true'),
			('include_year_in_album', 'false'),
			('tag_writing_enabled', 'true'),
			('clear_existing_tags', 'false'),
			('embed_artwork', 'true'),
			('artwork_max_size', '600'),
			('backup_before_tagging', 'false'),
			('backup_folder', '');
		`,
	},
	{
		Version: 3,
		Name:    "create_recognition_cache_table",
		SQL: `
		CREATE TABLE IF NOT EXISTS recognition_cache (
			file_hash TEXT PRIMARY KEY,
			response TEXT,
			service TEXT,
			ip_address TEXT,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP
		);
		`,
	},
	{
		Version: 4,
		Name:    "create_logs_table",
		SQL: `
		CREATE TABLE IF NOT EXISTS logs (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			level TEXT NOT NULL,
			message TEXT NOT NULL,
			file_id INTEGER,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			FOREIGN KEY (file_id) REFERENCES files(id) ON DELETE SET NULL
		);

		CREATE INDEX IF NOT EXISTS idx_logs_level ON logs(level);
		CREATE INDEX IF NOT EXISTS idx_logs_created_at ON logs(created_at);
		`,
	},
}

// runMigrations runs all pending migrations
func runMigrations() error {
	// Create migrations table if not exists
	_, err := db.Exec(`
		CREATE TABLE IF NOT EXISTS schema_migrations (
			version INTEGER PRIMARY KEY,
			name TEXT NOT NULL,
			applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
		)
	`)
	if err != nil {
		return fmt.Errorf("failed to create migrations table: %w", err)
	}

	// Get current version
	var currentVersion int
	err = db.QueryRow("SELECT COALESCE(MAX(version), 0) FROM schema_migrations").Scan(&currentVersion)
	if err != nil {
		return fmt.Errorf("failed to get current migration version: %w", err)
	}

	// Run pending migrations
	for _, m := range migrations {
		if m.Version <= currentVersion {
			continue
		}

		// Run migration in a transaction
		tx, err := db.Begin()
		if err != nil {
			return fmt.Errorf("failed to begin transaction for migration %d: %w", m.Version, err)
		}

		if _, err := tx.Exec(m.SQL); err != nil {
			tx.Rollback()
			return fmt.Errorf("failed to run migration %d (%s): %w", m.Version, m.Name, err)
		}

		if _, err := tx.Exec("INSERT INTO schema_migrations (version, name) VALUES (?, ?)", m.Version, m.Name); err != nil {
			tx.Rollback()
			return fmt.Errorf("failed to record migration %d: %w", m.Version, err)
		}

		if err := tx.Commit(); err != nil {
			return fmt.Errorf("failed to commit migration %d: %w", m.Version, err)
		}

		fmt.Printf("Applied migration %d: %s\n", m.Version, m.Name)
	}

	return nil
}
