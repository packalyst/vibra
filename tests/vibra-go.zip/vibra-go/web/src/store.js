/**
 * Simple state management store
 */

class Store {
    constructor() {
        this.state = {
            stats: {
                total: 0,
                recognized: 0,
                pending: 0,
                errors: 0,
            },
            settings: {},
            files: [],
            logs: [],
            progress: {
                active: false,
                type: null,
                current: 0,
                total: 0,
                currentFile: null,
            },
        };
        this.listeners = new Map();
    }

    getState() {
        return this.state;
    }

    get(key) {
        return key.split('.').reduce((obj, k) => obj?.[k], this.state);
    }

    set(key, value) {
        const keys = key.split('.');
        const last = keys.pop();
        const target = keys.reduce((obj, k) => {
            if (!(k in obj)) obj[k] = {};
            return obj[k];
        }, this.state);

        target[last] = value;
        this.emit(key, value);
        this.emit('change', { key, value });
    }

    update(key, updater) {
        const current = this.get(key);
        const next = typeof updater === 'function' ? updater(current) : { ...current, ...updater };
        this.set(key, next);
    }

    on(key, callback) {
        if (!this.listeners.has(key)) {
            this.listeners.set(key, []);
        }
        this.listeners.get(key).push(callback);

        return () => this.off(key, callback);
    }

    off(key, callback) {
        if (!this.listeners.has(key)) return;

        const callbacks = this.listeners.get(key);
        const index = callbacks.indexOf(callback);
        if (index > -1) {
            callbacks.splice(index, 1);
        }
    }

    emit(key, value) {
        if (!this.listeners.has(key)) return;

        for (const callback of this.listeners.get(key)) {
            try {
                callback(value);
            } catch (error) {
                console.error(`Error in store listener for ${key}:`, error);
            }
        }
    }

    // Convenience methods
    updateStats(stats) {
        this.set('stats', stats);
    }

    updateSettings(settings) {
        this.set('settings', settings);
    }

    updateFiles(files) {
        this.set('files', files);
    }

    addLog(log) {
        const logs = this.get('logs') || [];
        logs.push({
            ...log,
            timestamp: log.timestamp || new Date().toISOString(),
        });

        // Keep only last 1000 logs
        if (logs.length > 1000) {
            logs.shift();
        }

        this.set('logs', logs);
    }

    clearLogs() {
        this.set('logs', []);
    }

    setProgress(progress) {
        this.set('progress', progress);
    }

    resetProgress() {
        this.set('progress', {
            active: false,
            type: null,
            current: 0,
            total: 0,
            currentFile: null,
        });
    }
}

export const store = new Store();
export default store;
