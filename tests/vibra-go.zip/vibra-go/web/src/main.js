/**
 * Vibra Music Organizer - Main Entry Point
 */

import { router } from './router.js';
import { api } from './api.js';
import { ws } from './websocket.js';
import { store } from './store.js';

// Page handlers
import { initDashboard } from './pages/dashboard.js';
import { initSettings } from './pages/settings.js';
import { initFiles } from './pages/files.js';
import { initLogs } from './pages/logs.js';

// Initialize application
async function init() {
    console.log('Vibra Music Organizer starting...');

    // Setup routes
    router.register('/', () => {
        const content = router.getTemplate('template-dashboard');
        setTimeout(() => initDashboard(), 0);
        return content;
    });

    router.register('/files', () => {
        const content = router.getTemplate('template-files');
        setTimeout(() => initFiles(), 0);
        return content;
    });

    router.register('/settings', () => {
        const content = router.getTemplate('template-settings');
        setTimeout(() => initSettings(), 0);
        return content;
    });

    router.register('/logs', () => {
        const content = router.getTemplate('template-logs');
        setTimeout(() => initLogs(), 0);
        return content;
    });

    // Initialize router
    router.init();

    // Connect WebSocket
    ws.connect();

    // Setup WebSocket event handlers
    setupWebSocketHandlers();

    // Load initial data
    await loadInitialData();
}

function setupWebSocketHandlers() {
    // Progress updates
    ws.on('scan_progress', (data) => {
        store.setProgress({
            active: true,
            type: 'scan',
            current: data.imported,
            total: data.total,
            currentFile: `Scanning... ${data.scanned} files found`,
        });
        updateProgressUI();
    });

    ws.on('analyze_progress', (data) => {
        store.setProgress({
            active: true,
            type: 'analyze',
            current: data.current,
            total: data.total,
            currentFile: data.file,
        });
        updateProgressUI();
    });

    ws.on('organize_progress', (data) => {
        store.setProgress({
            active: true,
            type: 'organize',
            current: data.current,
            total: data.total,
            currentFile: data.file,
        });
        updateProgressUI();
    });

    // Log events
    ws.on('log', (data) => {
        store.addLog(data);
        appendLiveLog(data);
    });

    // Rate limiting
    ws.on('rate_limit', (data) => {
        store.addLog({
            level: 'warn',
            message: data.paused
                ? `Rate limited - ${data.proxyRotating ? 'rotating proxy' : 'waiting'}...`
                : 'Rate limit cleared, resuming...',
        });
    });

    // Proxy rotation
    ws.on('proxy_rotated', (data) => {
        store.addLog({
            level: 'info',
            message: `Proxy rotated: ${data.oldIP} → ${data.newIP}`,
        });
    });

    // Error events
    ws.on('error', (data) => {
        store.addLog({
            level: 'error',
            message: data.message || 'Unknown error',
        });
    });

    // Stats update
    ws.on('stats_update', (data) => {
        store.updateStats(data);
        updateStatsUI();
    });

    // Task complete
    ws.on('task_complete', (data) => {
        store.resetProgress();
        updateProgressUI();
        loadStats();
    });
}

async function loadInitialData() {
    try {
        await Promise.all([
            loadStats(),
            loadSettings(),
        ]);
    } catch (error) {
        console.error('Failed to load initial data:', error);
    }
}

async function loadStats() {
    try {
        const stats = await api.getStats();
        store.updateStats(stats);
        updateStatsUI();
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function loadSettings() {
    try {
        const settings = await api.getSettings();
        store.updateSettings(settings);
    } catch (error) {
        console.error('Failed to load settings:', error);
    }
}

function updateStatsUI() {
    const stats = store.get('stats');
    if (!stats) return;

    const elements = {
        'stat-total': stats.total ?? 0,
        'stat-recognized': stats.recognized ?? 0,
        'stat-pending': stats.pending ?? 0,
        'stat-errors': stats.errors ?? 0,
    };

    for (const [id, value] of Object.entries(elements)) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }
}

function updateProgressUI() {
    const progress = store.get('progress');
    const section = document.getElementById('progress-section');

    if (!section) return;

    if (!progress || !progress.active) {
        section.classList.add('hidden');
        return;
    }

    section.classList.remove('hidden');

    const percent = progress.total > 0
        ? Math.round((progress.current / progress.total) * 100)
        : 0;

    const labels = {
        scan: 'Scanning files...',
        analyze: 'Analyzing files...',
        organize: 'Organizing files...',
    };

    document.getElementById('progress-label').textContent = labels[progress.type] || 'Processing...';
    document.getElementById('progress-percent').textContent = `${percent}% (${progress.current}/${progress.total})`;
    document.getElementById('progress-bar').style.width = `${percent}%`;
    document.getElementById('progress-current').textContent = progress.currentFile || '-';
}

function appendLiveLog(log) {
    const container = document.getElementById('live-log');
    if (!container) return;

    // Remove "waiting" message if present
    const waiting = container.querySelector('.text-gray-500');
    if (waiting && waiting.textContent.includes('Waiting')) {
        waiting.remove();
    }

    const colors = {
        debug: 'text-gray-400',
        info: 'text-blue-400',
        warn: 'text-yellow-400',
        error: 'text-red-400',
    };

    const div = document.createElement('div');
    div.className = colors[log.level] || 'text-white';

    const time = new Date(log.timestamp || Date.now()).toLocaleTimeString();
    div.textContent = `[${time}] [${log.level?.toUpperCase() || 'INFO'}] ${log.message}`;

    container.appendChild(div);

    // Auto-scroll to bottom
    container.scrollTop = container.scrollHeight;

    // Limit entries
    while (container.children.length > 500) {
        container.removeChild(container.firstChild);
    }
}

// Expose for page modules
window.vibra = {
    api,
    ws,
    store,
    router,
    loadStats,
    loadSettings,
    updateStatsUI,
    updateProgressUI,
    appendLiveLog,
};

// Start app when DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
