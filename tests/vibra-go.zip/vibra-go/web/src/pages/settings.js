/**
 * Settings page handler
 */

import { api } from '../api.js';
import { store } from '../store.js';

export function initSettings() {
    loadSettings();
    setupForm();
    setupProxyTest();
    setupRangeInputs();
}

async function loadSettings() {
    try {
        const settings = await api.getSettings();
        store.updateSettings(settings);
        populateForm(settings);
    } catch (error) {
        console.error('Failed to load settings:', error);
        window.showToast?.('Failed to load settings', 'error');
    }
}

function populateForm(settings) {
    const form = document.getElementById('settings-form');
    if (!form) return;

    // Paths
    setInputValue(form, 'watch_folder', settings.watch_folder);
    setInputValue(form, 'output_folder', settings.output_folder);

    // Proxy
    if (settings.proxy) {
        setCheckbox(form, 'proxy_enabled', settings.proxy.enabled);
        setInputValue(form, 'proxy_host', settings.proxy.host);
        setInputValue(form, 'proxy_port', settings.proxy.port);
        setInputValue(form, 'proxy_type', settings.proxy.type);
        setInputValue(form, 'proxy_username', settings.proxy.username);
        setInputValue(form, 'proxy_password', settings.proxy.password);
        setInputValue(form, 'proxy_rotation_url', settings.proxy.rotation_url);
    }

    // Services
    if (settings.services) {
        setCheckbox(form, 'shazam_enabled', settings.services.shazam_enabled);
        setCheckbox(form, 'acoustid_enabled', settings.services.acoustid_enabled);
        setInputValue(form, 'acoustid_api_key', settings.services.acoustid_api_key);
    }

    // Processing
    if (settings.processing) {
        setInputValue(form, 'workers', settings.processing.workers);
        setInputValue(form, 'batch_size', settings.processing.batch_size);
        setInputValue(form, 'delay_between_ms', settings.processing.delay_between_ms);
        updateRangeDisplay('workers', settings.processing.workers);
    }
}

function setInputValue(form, name, value) {
    const input = form.querySelector(`[name="${name}"]`);
    if (input && value !== undefined && value !== null) {
        input.value = value;
    }
}

function setCheckbox(form, name, checked) {
    const input = form.querySelector(`[name="${name}"]`);
    if (input) {
        input.checked = !!checked;
    }
}

function setupForm() {
    const form = document.getElementById('settings-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const settings = {
            watch_folder: formData.get('watch_folder'),
            output_folder: formData.get('output_folder'),
            proxy: {
                enabled: formData.get('proxy_enabled') === 'on',
                host: formData.get('proxy_host'),
                port: parseInt(formData.get('proxy_port')) || 8080,
                type: formData.get('proxy_type'),
                username: formData.get('proxy_username'),
                password: formData.get('proxy_password'),
                rotation_url: formData.get('proxy_rotation_url'),
            },
            services: {
                shazam_enabled: formData.get('shazam_enabled') === 'on',
                acoustid_enabled: formData.get('acoustid_enabled') === 'on',
                acoustid_api_key: formData.get('acoustid_api_key'),
            },
            processing: {
                workers: parseInt(formData.get('workers')) || 4,
                batch_size: parseInt(formData.get('batch_size')) || 100,
                delay_between_ms: parseInt(formData.get('delay_between_ms')) || 0,
            },
        };

        try {
            await api.updateSettings(settings);
            store.updateSettings(settings);
            window.showToast?.('Settings saved', 'success');
        } catch (error) {
            console.error('Failed to save settings:', error);
            window.showToast?.(`Failed to save: ${error.message}`, 'error');
        }
    });
}

function setupProxyTest() {
    const btn = document.getElementById('btn-test-proxy');
    const result = document.getElementById('proxy-test-result');

    if (!btn || !result) return;

    btn.addEventListener('click', async () => {
        btn.disabled = true;
        btn.textContent = 'Testing...';
        result.textContent = '';
        result.className = 'ml-4 text-sm';

        try {
            const response = await api.testProxy();
            if (response.success) {
                result.textContent = `Connected! IP: ${response.ip}`;
                result.classList.add('text-green-400');
            } else {
                result.textContent = response.message || 'Connection failed';
                result.classList.add('text-red-400');
            }
        } catch (error) {
            result.textContent = error.message || 'Connection failed';
            result.classList.add('text-red-400');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Test Proxy Connection';
        }
    });
}

function setupRangeInputs() {
    const workersInput = document.querySelector('input[name="workers"]');
    if (workersInput) {
        workersInput.addEventListener('input', (e) => {
            updateRangeDisplay('workers', e.target.value);
        });
    }
}

function updateRangeDisplay(name, value) {
    const display = document.getElementById(`${name}-value`);
    if (display) {
        display.textContent = value;
    }
}
