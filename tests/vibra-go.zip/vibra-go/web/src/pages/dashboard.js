/**
 * Dashboard page handler
 */

import { api } from '../api.js';
import { store } from '../store.js';

export function initDashboard() {
    setupActionButtons();
    setupLogControls();
    loadStats();
}

function setupActionButtons() {
    const btnScan = document.getElementById('btn-scan');
    const btnAnalyze = document.getElementById('btn-analyze');
    const btnOrganize = document.getElementById('btn-organize');

    if (btnScan) {
        btnScan.addEventListener('click', async () => {
            const settings = store.get('settings') || {};
            const folder = settings.watch_folder || '/music';

            setButtonLoading(btnScan, true);
            try {
                await api.scanFolder(folder);
                showToast('Scan started', 'info');
            } catch (error) {
                showToast(`Scan failed: ${error.message}`, 'error');
            } finally {
                setButtonLoading(btnScan, false);
            }
        });
    }

    if (btnAnalyze) {
        btnAnalyze.addEventListener('click', async () => {
            setButtonLoading(btnAnalyze, true);
            try {
                await api.analyzeFiles([]);  // Empty array = all pending
                showToast('Analysis started', 'info');
            } catch (error) {
                showToast(`Analysis failed: ${error.message}`, 'error');
            } finally {
                setButtonLoading(btnAnalyze, false);
            }
        });
    }

    if (btnOrganize) {
        btnOrganize.addEventListener('click', async () => {
            setButtonLoading(btnOrganize, true);
            try {
                await api.organizeFiles([]);  // Empty array = all recognized
                showToast('Organization started', 'info');
            } catch (error) {
                showToast(`Organization failed: ${error.message}`, 'error');
            } finally {
                setButtonLoading(btnOrganize, false);
            }
        });
    }
}

function setupLogControls() {
    const btnClear = document.getElementById('btn-clear-log');
    if (btnClear) {
        btnClear.addEventListener('click', () => {
            const container = document.getElementById('live-log');
            if (container) {
                container.innerHTML = '<div class="text-gray-500">Waiting for events...</div>';
            }
            store.clearLogs();
        });
    }
}

async function loadStats() {
    try {
        const stats = await api.getStats();
        store.updateStats(stats);
        updateStatsDisplay(stats);
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

function updateStatsDisplay(stats) {
    const elements = {
        'stat-total': stats.total ?? 0,
        'stat-recognized': stats.recognized ?? 0,
        'stat-pending': stats.pending ?? 0,
        'stat-errors': stats.errors ?? 0,
    };

    for (const [id, value] of Object.entries(elements)) {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }
}

function setButtonLoading(button, loading) {
    if (loading) {
        button.classList.add('btn-loading');
        button.disabled = true;
        const spinner = document.createElement('span');
        spinner.className = 'spinner';
        button.insertBefore(spinner, button.firstChild);
    } else {
        button.classList.remove('btn-loading');
        button.disabled = false;
        const spinner = button.querySelector('.spinner');
        if (spinner) spinner.remove();
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Make showToast available globally
window.showToast = showToast;
