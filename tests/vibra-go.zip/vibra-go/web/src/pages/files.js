/**
 * Files page handler
 */

import { api } from '../api.js';
import { store } from '../store.js';

let currentPage = 1;
let currentFilter = '';
const pageSize = 50;

export function initFiles() {
    setupFilters();
    loadFiles();
}

function setupFilters() {
    const statusFilter = document.getElementById('filter-status');
    if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
            currentFilter = e.target.value;
            currentPage = 1;
            loadFiles();
        });
    }
}

async function loadFiles() {
    try {
        const params = {
            page: currentPage,
            limit: pageSize,
        };

        if (currentFilter) {
            params.status = currentFilter;
        }

        const response = await api.getFiles(params);
        store.updateFiles(response.files || []);
        renderFiles(response.files || []);
        renderPagination(response.total || 0);
    } catch (error) {
        console.error('Failed to load files:', error);
        window.showToast?.('Failed to load files', 'error');
    }
}

function renderFiles(files) {
    const tbody = document.getElementById('files-table-body');
    if (!tbody) return;

    if (files.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="px-6 py-8 text-center text-gray-400">
                    No files found. Click "Scan Folder" on the Dashboard to import files.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = files.map(file => `
        <tr class="cursor-pointer hover:bg-gray-700" data-id="${file.id}">
            <td class="px-6 py-4">
                <span class="status-badge status-${file.status}">${file.status}</span>
            </td>
            <td class="px-6 py-4">${escapeHtml(file.title || file.path?.split('/').pop() || '-')}</td>
            <td class="px-6 py-4">${escapeHtml(file.artist || '-')}</td>
            <td class="px-6 py-4">${escapeHtml(file.album || '-')}</td>
            <td class="px-6 py-4">${file.recognition_service || '-'}</td>
            <td class="px-6 py-4">${file.confidence ? `${Math.round(file.confidence * 100)}%` : '-'}</td>
        </tr>
    `).join('');

    // Add click handlers
    tbody.querySelectorAll('tr[data-id]').forEach(row => {
        row.addEventListener('click', () => {
            showFileDetail(parseInt(row.dataset.id));
        });
    });
}

function renderPagination(total) {
    const container = document.getElementById('pagination');
    if (!container) return;

    const totalPages = Math.ceil(total / pageSize);

    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }

    let html = '';

    // Previous button
    if (currentPage > 1) {
        html += `<button class="px-3 py-1 bg-gray-700 rounded hover:bg-gray-600" data-page="${currentPage - 1}">Prev</button>`;
    }

    // Page numbers
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);

    for (let i = startPage; i <= endPage; i++) {
        const active = i === currentPage ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600';
        html += `<button class="px-3 py-1 rounded ${active}" data-page="${i}">${i}</button>`;
    }

    // Next button
    if (currentPage < totalPages) {
        html += `<button class="px-3 py-1 bg-gray-700 rounded hover:bg-gray-600" data-page="${currentPage + 1}">Next</button>`;
    }

    container.innerHTML = html;

    // Add click handlers
    container.querySelectorAll('button[data-page]').forEach(btn => {
        btn.addEventListener('click', () => {
            currentPage = parseInt(btn.dataset.page);
            loadFiles();
        });
    });
}

async function showFileDetail(id) {
    try {
        const file = await api.getFile(id);
        showModal(file);
    } catch (error) {
        console.error('Failed to load file details:', error);
        window.showToast?.('Failed to load file details', 'error');
    }
}

function showModal(file) {
    // Remove existing modal
    const existing = document.getElementById('file-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'file-modal';
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-gray-800 rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
            <div class="flex justify-between items-start mb-6">
                <h3 class="text-xl font-bold">File Details</h3>
                <button id="modal-close" class="text-gray-400 hover:text-white text-2xl">&times;</button>
            </div>

            <div class="flex gap-6">
                ${file.artwork_url ? `
                    <div class="flex-shrink-0">
                        <img src="${file.artwork_url}" alt="Artwork" class="w-40 h-40 rounded-lg object-cover">
                    </div>
                ` : ''}
                <div class="flex-grow space-y-4">
                    <div>
                        <div class="text-sm text-gray-400">Title</div>
                        <div class="text-lg">${escapeHtml(file.title || '-')}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Artist</div>
                        <div>${escapeHtml(file.artist || '-')}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Album</div>
                        <div>${escapeHtml(file.album || '-')}</div>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <div class="text-sm text-gray-400">Year</div>
                            <div>${file.year || '-'}</div>
                        </div>
                        <div>
                            <div class="text-sm text-gray-400">Genre</div>
                            <div>${escapeHtml(file.genre || '-')}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-6 pt-6 border-t border-gray-700 space-y-4">
                <div>
                    <div class="text-sm text-gray-400">File Path</div>
                    <div class="text-sm font-mono break-all">${escapeHtml(file.path || '-')}</div>
                </div>
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <div class="text-sm text-gray-400">Status</div>
                        <span class="status-badge status-${file.status}">${file.status}</span>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Service</div>
                        <div>${file.recognition_service || '-'}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Confidence</div>
                        <div>${file.confidence ? `${Math.round(file.confidence * 100)}%` : '-'}</div>
                    </div>
                </div>
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <div class="text-sm text-gray-400">Codec</div>
                        <div>${file.codec || '-'}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Bitrate</div>
                        <div>${file.bitrate ? `${file.bitrate} kbps` : '-'}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Duration</div>
                        <div>${file.duration ? formatDuration(file.duration) : '-'}</div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Close handlers
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.remove();
    });

    document.getElementById('modal-close').addEventListener('click', () => modal.remove());

    document.addEventListener('keydown', function handler(e) {
        if (e.key === 'Escape') {
            modal.remove();
            document.removeEventListener('keydown', handler);
        }
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
}

function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}
