/**
 * Logs page handler
 */

import { store } from '../store.js';
import { ws } from '../websocket.js';

let currentLevelFilter = '';
let autoScroll = true;

export function initLogs() {
    setupFilters();
    setupExport();
    renderLogs();
    setupWebSocketLogs();
}

function setupFilters() {
    const levelFilter = document.getElementById('log-level-filter');
    if (levelFilter) {
        levelFilter.addEventListener('change', (e) => {
            currentLevelFilter = e.target.value;
            renderLogs();
        });
    }
}

function setupExport() {
    const btn = document.getElementById('btn-export-logs');
    if (btn) {
        btn.addEventListener('click', exportLogs);
    }
}

function setupWebSocketLogs() {
    ws.on('log', (data) => {
        appendLog(data);
    });
}

function renderLogs() {
    const container = document.getElementById('logs-container');
    if (!container) return;

    let logs = store.get('logs') || [];

    if (currentLevelFilter) {
        logs = logs.filter(log => log.level === currentLevelFilter);
    }

    if (logs.length === 0) {
        container.innerHTML = '<div class="text-gray-500">No logs to display</div>';
        return;
    }

    container.innerHTML = logs.map(log => formatLogEntry(log)).join('');

    if (autoScroll) {
        container.scrollTop = container.scrollHeight;
    }
}

function appendLog(log) {
    // Apply filter
    if (currentLevelFilter && log.level !== currentLevelFilter) {
        return;
    }

    const container = document.getElementById('logs-container');
    if (!container) return;

    // Remove "no logs" message if present
    const empty = container.querySelector('.text-gray-500');
    if (empty && empty.textContent.includes('No logs')) {
        empty.remove();
    }

    const div = document.createElement('div');
    div.innerHTML = formatLogEntry(log);

    container.appendChild(div.firstElementChild);

    // Limit entries
    while (container.children.length > 1000) {
        container.removeChild(container.firstChild);
    }

    // Auto-scroll if enabled
    if (autoScroll) {
        container.scrollTop = container.scrollHeight;
    }
}

function formatLogEntry(log) {
    const colors = {
        debug: 'log-debug',
        info: 'log-info',
        warn: 'log-warn',
        error: 'log-error',
    };

    const time = formatTime(log.timestamp);
    const level = (log.level || 'info').toUpperCase().padEnd(5);
    const colorClass = colors[log.level] || 'text-white';

    return `<div class="${colorClass}">[${time}] [${level}] ${escapeHtml(log.message)}</div>`;
}

function formatTime(timestamp) {
    if (!timestamp) return new Date().toLocaleTimeString();

    try {
        return new Date(timestamp).toLocaleTimeString();
    } catch {
        return timestamp;
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
}

function exportLogs() {
    const logs = store.get('logs') || [];

    if (logs.length === 0) {
        window.showToast?.('No logs to export', 'info');
        return;
    }

    const content = logs.map(log => {
        const time = formatTime(log.timestamp);
        const level = (log.level || 'info').toUpperCase();
        return `[${time}] [${level}] ${log.message}`;
    }).join('\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `vibra-logs-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    URL.revokeObjectURL(url);

    window.showToast?.('Logs exported', 'success');
}
