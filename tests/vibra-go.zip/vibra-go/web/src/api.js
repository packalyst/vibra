/**
 * API Client for Vibra backend
 */

const API_BASE = '/api';

class ApiClient {
    constructor() {
        this.baseUrl = API_BASE;
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers,
            },
            ...options,
        };

        try {
            const response = await fetch(url, config);

            if (!response.ok) {
                const error = await response.json().catch(() => ({ error: response.statusText }));
                throw new Error(error.error || error.message || `HTTP ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error(`API Error [${endpoint}]:`, error);
            throw error;
        }
    }

    // Stats
    async getStats() {
        return this.request('/stats');
    }

    // Files
    async getFiles(params = {}) {
        const query = new URLSearchParams(params).toString();
        return this.request(`/files${query ? '?' + query : ''}`);
    }

    async getFile(id) {
        return this.request(`/files/${id}`);
    }

    async scanFolder(path) {
        return this.request('/files/scan', {
            method: 'POST',
            body: JSON.stringify({ path }),
        });
    }

    async analyzeFiles(fileIds) {
        return this.request('/files/analyze', {
            method: 'POST',
            body: JSON.stringify({ file_ids: fileIds }),
        });
    }

    async organizeFiles(fileIds) {
        return this.request('/files/organize', {
            method: 'POST',
            body: JSON.stringify({ file_ids: fileIds }),
        });
    }

    // Settings
    async getSettings() {
        return this.request('/settings');
    }

    async updateSettings(settings) {
        return this.request('/settings', {
            method: 'PUT',
            body: JSON.stringify(settings),
        });
    }

    async testProxy() {
        return this.request('/settings/test-proxy', {
            method: 'POST',
        });
    }
}

export const api = new ApiClient();
export default api;
