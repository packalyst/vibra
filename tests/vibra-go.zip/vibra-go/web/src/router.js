/**
 * Simple hash-based SPA router
 */

class Router {
    constructor() {
        this.routes = new Map();
        this.currentPage = null;
        this.contentEl = null;
    }

    init() {
        this.contentEl = document.getElementById('page-content');

        // Listen for hash changes
        window.addEventListener('hashchange', () => this.navigate());

        // Initial navigation
        this.navigate();
    }

    register(path, handler) {
        this.routes.set(path, handler);
    }

    navigate(path) {
        if (path) {
            window.location.hash = path;
            return;
        }

        const hash = window.location.hash.slice(1) || '/';
        const route = this.matchRoute(hash);

        if (route) {
            this.render(route.handler, route.params);
            this.updateNavLinks(hash);
        } else {
            // Default to dashboard
            this.navigate('/');
        }
    }

    matchRoute(path) {
        // Exact match first
        if (this.routes.has(path)) {
            return { handler: this.routes.get(path), params: {} };
        }

        // Pattern matching for dynamic routes
        for (const [pattern, handler] of this.routes) {
            const regex = this.patternToRegex(pattern);
            const match = path.match(regex);

            if (match) {
                const params = this.extractParams(pattern, match);
                return { handler, params };
            }
        }

        return null;
    }

    patternToRegex(pattern) {
        const escaped = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const withParams = escaped.replace(/\\:(\w+)/g, '([^/]+)');
        return new RegExp(`^${withParams}$`);
    }

    extractParams(pattern, match) {
        const params = {};
        const paramNames = pattern.match(/:(\w+)/g) || [];

        paramNames.forEach((name, index) => {
            params[name.slice(1)] = match[index + 1];
        });

        return params;
    }

    render(handler, params = {}) {
        if (!this.contentEl) return;

        try {
            const content = handler(params);

            if (typeof content === 'string') {
                this.contentEl.innerHTML = content;
            } else if (content instanceof HTMLElement) {
                this.contentEl.innerHTML = '';
                this.contentEl.appendChild(content);
            } else if (content instanceof DocumentFragment) {
                this.contentEl.innerHTML = '';
                this.contentEl.appendChild(content);
            }

            // Dispatch page change event
            window.dispatchEvent(new CustomEvent('pagechange', {
                detail: { params }
            }));
        } catch (error) {
            console.error('Error rendering page:', error);
            this.contentEl.innerHTML = `
                <div class="text-red-500">
                    <h2>Error loading page</h2>
                    <p>${error.message}</p>
                </div>
            `;
        }
    }

    updateNavLinks(currentPath) {
        const links = document.querySelectorAll('.nav-link');

        links.forEach(link => {
            const href = link.getAttribute('href')?.slice(1) || '/';

            if (href === currentPath || (currentPath === '/' && href === '/')) {
                link.classList.add('bg-gray-700', 'text-white');
                link.classList.remove('text-gray-300');
            } else {
                link.classList.remove('bg-gray-700', 'text-white');
                link.classList.add('text-gray-300');
            }
        });
    }

    getTemplate(id) {
        const template = document.getElementById(id);
        if (!template) {
            console.error(`Template not found: ${id}`);
            return document.createDocumentFragment();
        }
        return template.content.cloneNode(true);
    }
}

export const router = new Router();
export default router;
