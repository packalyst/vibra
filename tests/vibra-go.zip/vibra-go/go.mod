module github.com/packalyst/vibra-go

go 1.22

require (
	github.com/go-chi/chi/v5 v5.1.0
	github.com/go-chi/cors v1.2.1
	github.com/gorilla/websocket v1.5.3
	github.com/mattn/go-sqlite3 v1.14.24
	github.com/spf13/cobra v1.8.1
	github.com/bogem/id3v2/v2 v2.1.4
	github.com/dhowden/tag v0.0.0-20240417053706-3d75831295e8
	golang.org/x/net v0.29.0
)

require (
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
	golang.org/x/text v0.18.0 // indirect
)
