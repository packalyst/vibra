package metadata

import (
	"strings"
)

// Unified represents merged metadata from multiple recognition services
type Unified struct {
	// Core metadata
	Title       string   `json:"title"`
	Artist      string   `json:"artist"`
	Album       string   `json:"album"`
	Year        int      `json:"year,omitempty"`
	Genre       string   `json:"genre,omitempty"`
	Genres      []string `json:"genres,omitempty"`
	TrackNumber int      `json:"track_number,omitempty"`
	DiscNumber  int      `json:"disc_number,omitempty"`
	Duration    float64  `json:"duration,omitempty"`
	ISRC        string   `json:"isrc,omitempty"`

	// Extended metadata
	FeatArtists []string `json:"feat_artists,omitempty"`
	Composer    string   `json:"composer,omitempty"`
	Label       string   `json:"label,omitempty"`
	Copyright   string   `json:"copyright,omitempty"`
	ReleaseDate string   `json:"release_date,omitempty"`

	// External IDs
	ShazamID      string `json:"shazam_id,omitempty"`
	MusicBrainzID string `json:"musicbrainz_id,omitempty"`
	ITunesID      string `json:"itunes_id,omitempty"`
	SpotifyID     string `json:"spotify_id,omitempty"`

	// Artwork
	ArtworkURL   string `json:"artwork_url,omitempty"`
	ArtworkURLHQ string `json:"artwork_url_hq,omitempty"`

	// Links
	ShazamURL      string `json:"shazam_url,omitempty"`
	AppleMusicURL  string `json:"apple_music_url,omitempty"`
	SpotifyURL     string `json:"spotify_url,omitempty"`
	PreviewURL     string `json:"preview_url,omitempty"`
	YouTubeMusicURL string `json:"youtube_music_url,omitempty"`

	// Recognition info
	Service    string  `json:"service"`     // Which service provided the primary match
	Confidence float64 `json:"confidence"`  // 0.0 to 1.0
	Sources    map[string]bool `json:"sources"` // Which services contributed data
}

// NewUnified creates a new empty Unified metadata
func NewUnified() *Unified {
	return &Unified{
		Sources: make(map[string]bool),
	}
}

// Merge merges another metadata source into this one
// Fields are only overwritten if the new value has higher confidence or fills gaps
func (u *Unified) Merge(other *Unified, minConfidenceDelta float64) {
	if other == nil {
		return
	}

	// Track source
	if other.Service != "" {
		u.Sources[other.Service] = true
	}

	// Higher confidence wins for primary match
	if other.Confidence > u.Confidence+minConfidenceDelta {
		u.Title = other.Title
		u.Artist = other.Artist
		u.Service = other.Service
		u.Confidence = other.Confidence
	}

	// Fill in gaps (prefer non-empty values)
	if u.Album == "" && other.Album != "" {
		u.Album = other.Album
	}
	if u.Year == 0 && other.Year != 0 {
		u.Year = other.Year
	}
	if u.Genre == "" && other.Genre != "" {
		u.Genre = other.Genre
	}
	if len(u.Genres) == 0 && len(other.Genres) > 0 {
		u.Genres = other.Genres
	}
	if u.TrackNumber == 0 && other.TrackNumber != 0 {
		u.TrackNumber = other.TrackNumber
	}
	if u.DiscNumber == 0 && other.DiscNumber != 0 {
		u.DiscNumber = other.DiscNumber
	}
	if u.Duration == 0 && other.Duration != 0 {
		u.Duration = other.Duration
	}
	if u.ISRC == "" && other.ISRC != "" {
		u.ISRC = other.ISRC
	}
	if len(u.FeatArtists) == 0 && len(other.FeatArtists) > 0 {
		u.FeatArtists = other.FeatArtists
	}
	if u.Composer == "" && other.Composer != "" {
		u.Composer = other.Composer
	}
	if u.Label == "" && other.Label != "" {
		u.Label = other.Label
	}
	if u.ReleaseDate == "" && other.ReleaseDate != "" {
		u.ReleaseDate = other.ReleaseDate
	}

	// External IDs - take any we don't have
	if u.ShazamID == "" && other.ShazamID != "" {
		u.ShazamID = other.ShazamID
	}
	if u.MusicBrainzID == "" && other.MusicBrainzID != "" {
		u.MusicBrainzID = other.MusicBrainzID
	}
	if u.ITunesID == "" && other.ITunesID != "" {
		u.ITunesID = other.ITunesID
	}
	if u.SpotifyID == "" && other.SpotifyID != "" {
		u.SpotifyID = other.SpotifyID
	}

	// Artwork - prefer higher quality
	if u.ArtworkURL == "" && other.ArtworkURL != "" {
		u.ArtworkURL = other.ArtworkURL
	}
	if other.ArtworkURLHQ != "" {
		u.ArtworkURLHQ = other.ArtworkURLHQ
	}

	// Links
	if u.ShazamURL == "" && other.ShazamURL != "" {
		u.ShazamURL = other.ShazamURL
	}
	if u.AppleMusicURL == "" && other.AppleMusicURL != "" {
		u.AppleMusicURL = other.AppleMusicURL
	}
	if u.SpotifyURL == "" && other.SpotifyURL != "" {
		u.SpotifyURL = other.SpotifyURL
	}
	if u.PreviewURL == "" && other.PreviewURL != "" {
		u.PreviewURL = other.PreviewURL
	}
}

// IsComplete returns true if we have essential metadata
func (u *Unified) IsComplete() bool {
	return u.Title != "" && u.Artist != ""
}

// IsHighConfidence returns true if confidence is above threshold
func (u *Unified) IsHighConfidence(threshold float64) bool {
	return u.Confidence >= threshold
}

// CleanTitle removes common noise from titles
func (u *Unified) CleanTitle() string {
	title := u.Title
	// Remove common suffixes like "(Official Video)", "[Remastered]", etc.
	suffixes := []string{
		"(Official Video)", "(Official Audio)", "(Official Music Video)",
		"(Lyric Video)", "(Lyrics)", "(Audio)",
		"[Remastered]", "[Remaster]", "(Remastered)", "(Remaster)",
		"[Official Video]", "[Official Audio]",
	}
	for _, suffix := range suffixes {
		title = strings.TrimSuffix(title, suffix)
		title = strings.TrimSuffix(title, " "+suffix)
	}
	return strings.TrimSpace(title)
}

// GetPrimaryGenre returns the first/primary genre
func (u *Unified) GetPrimaryGenre() string {
	if u.Genre != "" {
		return u.Genre
	}
	if len(u.Genres) > 0 {
		return u.Genres[0]
	}
	return ""
}

// GetBestArtworkURL returns the highest quality artwork URL available
func (u *Unified) GetBestArtworkURL() string {
	if u.ArtworkURLHQ != "" {
		return u.ArtworkURLHQ
	}
	return u.ArtworkURL
}
